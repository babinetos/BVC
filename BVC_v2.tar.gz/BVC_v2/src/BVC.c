/* cc -o start_BVC start_BVC.c ../lib/*.a -I../lib/ -lm -lf77blas -lcblas -latlas */

#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "vec_mat.h"
#include "files.h"
#include "rans.h"
#include "distributions.h"
#include "MCMCEM_functions.h"


#include <gsl/gsl_cdf.h>
#include <gsl/gsl_multimin.h>
#include <gsl_cblas.h> 

#include <gsl/gsl_roots.h>

double gsl_one_grad_null_Q_beta_f(double v, void *params);
double null_one_hess_Q_beta_f(double beta, void *params);
void gsl_one_both_hess_null_Q_beta_f(double v, void *params,double *f,double *df);
double gsl_Q_null_beta_f(const gsl_vector *v, void *params);
void gsl_grad_Q_null_beta_f(const gsl_vector *v, void *params,gsl_vector *df);
void gsl_both_Q_null_beta_f(const gsl_vector *v, void *params,double *f,gsl_vector *df);

double gsl_Q_beta_f(const gsl_vector *v, void *params);
void gsl_grad_Q_beta_f(const gsl_vector *v, void *params,gsl_vector *df);
void gsl_both_Q_beta_f(const gsl_vector *v, void *params,double *f,gsl_vector *df);
double gsl_Q_sigma_f(const gsl_vector *v, void *params);
void gsl_grad_Q_sigma_f(const gsl_vector *v, void *params,gsl_vector *df);
void gsl_both_Q_sigma_f(const gsl_vector *v, void *params,double *f,gsl_vector *df);

double gsl_one_Q_beta_f(double v, void *params);
double gsl_one_grad_Q_beta_f(double v, void *params);
void gsl_one_both_Q_beta_f(double v, void *params,double *f,double *df);

double one_hess_Q_beta_f(double beta,void *params);
void gsl_one_both_hess_Q_beta_f(double v, void *params,double *f,double *df);


/* double Q1_beta_f(double *betas); */


/* ################################################################ */
/* ################################################################ */
/* ################################################################ */
int low_MC=0000;
double incre=1.0;        /* Max percentage of increase of MC replicates */
int consec=4;
double CHI_25_percentiles[11]= {0, 1.323304,  2.772589,  4.108345,  5.385269,  6.625680,  7.840804,  9.037148, 10.218855, 11.388751, 12.548861};
/* ####################################### */


double log_Q_f(double *betas, double *sigmas);

double rand_unif_f(double a, double b)
{
  double u;
  u=rans();
  
  u=a+u*(b-a);
  return u;
}

int word_cnt(char *s)
{

  /* function that counts the item on a  */
  /* string(line) separated by blanks    */

  int cnt=0;
  while(*s !='\0'){
    while(isspace(*s))
      ++s;
    if(*s !='\0'){
      ++cnt;
      while( !isspace(*s) && *s !='\0')
             ++s;
    }
  }  
       return cnt;
}



int fdf_mininize_f( const gsl_vector *x,gsl_multimin_function_fdf my_func,gsl_multimin_fdfminimizer *s, double init_step, int max_iter, double tol)
{
  int iter=0,status;
  
  gsl_multimin_fdfminimizer_set (s, &my_func, x, init_step,tol);
     
  do
    {
      iter++;
      status = gsl_multimin_fdfminimizer_iterate (s);
     
      if (status)
	break;
     
      status = gsl_multimin_test_gradient (s->gradient, tol);
      
    }
       while (status == GSL_CONTINUE && iter < max_iter);
 
  return status;
}

int one_fdf_root_find_f( double x,gsl_function_fdf FDF,gsl_root_fdfsolver *s, int maxite, double tol)
{
  int iter=0,status;
  gsl_root_fdfsolver_set (s, &FDF, x);
     
  do
    {
      iter++;
      status = gsl_root_fdfsolver_iterate (s);
      if (status)
	break;
      
      status = gsl_root_test_delta (gsl_root_fdfsolver_root (s), x,0, tol );
      
    }
  while (status == GSL_CONTINUE && iter < maxite);
 
  return status;
}

/*################################################################*/
/*################################################################*/
#define PI 3.14159265
int screen=0;


int main (int argc, char **argv)
{
  int i,j,k,l,s=0;
  int map_flag=0,seed_flag=0;
  int arg;
  FILE *out;
  char cmd[20];

  FILE *in;

  char pedfile[MAXLEN] = "pedigree";
  char mapfile[MAXLEN] = "marker.loc";
  char infofile[MAXLEN] = "info";
  char outfile[MAXLEN] = "out.txt";
  char seedfile[MAXLEN] ;
  if (argc > 1) {
      for (arg=1; arg < argc && argv[arg][0] == '-'; arg++) {
         switch (argv[arg][1])
            {
            case 'p':
               strncpy(pedfile, argv[++arg], MAXLEN);
               fflush(stdout);
               break;
           case 'i':
               strncpy(infofile, argv[++arg], MAXLEN);
               break;
           case 'm':
               strncpy(mapfile, argv[++arg], MAXLEN);
	       map_flag=1;
               break;
           case 'o':
               strncpy(outfile, argv[++arg], MAXLEN);
               break;
            case '-':
	      
	      strncpy(cmd, &argv[arg][2], 15);


	      if( !strcmp(cmd,"screen"))
		screen = 1;

  	      if( !strcmp(cmd,"seed"))
		{
		  strncpy(seedfile, argv[++arg], MAXLEN);
		  fflush(stdout);
		  seed_flag=1;
		}
             break;
            default:
               fprintf (stderr, "Unknown option \"%s\"\n", argv[arg]);
               exit(1);
            }
      }
   }
  uint32 cseed, tseed;
 
  uint32 iseed1, iseed2;

  if(seed_flag==1)
    {
      get_seeds(seedfile); 
    }else
    {      
      iseed1 = floor(time(NULL));
      iseed2 = floor(iseed1+time(NULL)%19);
      setsd(iseed1,iseed2);
    }

  MAP.markers=0;
  if(map_flag==1)
    read_marker_info_f(mapfile);

  readped(pedfile); /* Linkage format */
  ped_check_f(pedfile);

  read_pois_grid_info(infofile);
  if(ped.npeople > 200)
    incre=10.0;
  double *null_weights;
  ln2pi=log(2*PI);

  MC_U=alloc_DMATRIX(MAXMC,ped.npeople); /* Matrix with MC samples of U[i]'s */
  null_weights=dvector(MAXMC); /* NULL weights for importance sampling */
  weights=dvector(MAXMC); /* Current weights for importance sampling */
  MC_outer=alloc_DMATRIX(ped.npeople,ped.npeople); /* outer product of MC samples */

  temp_MAT=alloc_DMATRIX(ped.npeople,ped.npeople);
/*   The Covariates part of the likelihood */

  double *betas,*null_betas;
  betas=dvector(ped.ncovars);
  null_betas=dvector(ped.ncovars);


  /* The Variance componenets part of the likelihood */

  double *sigmas,*null_sigmas;
  sigmas=dvector(nsigmas);
  null_sigmas=dvector(nsigmas);


/*    Initialization of variables */

  out=open_f(outfile,'a');
     
  int cont=1,conv=consec; /* consecutive times convergence criterion should be sutisfied*/
  double f1,f2,f;
  double chi_s=0,chi_b=0,chi,MC_alpha=.25;

  W=MC;
  for(i=0;i<MC;i++)
    weights[i]=1;
  double *pars;

  double *grad_s,*sigmas_hat,*grad_b;
  DMATRIX Hs,Hb;
  double *s_vars,*b_vars;
  /* initializing the gradient and hessian of */
  /* the Covariate part of likelihood        */

  if(ped.ncovars>0)
    {
      grad_b=dvector(ped.ncovars);
      b_vars=dvector(ped.ncovars);
      Hb=alloc_DMATRIX(ped.ncovars,ped.ncovars);
     for(i=0;i<ped.ncovars;i++)
	for(j=0;j<ped.ncovars;j++)
	  Hb.mat[i][j]=0;

      for(i=0;i<ped.ncovars;i++)
	Hb.mat[i][i]=1.0;
      s++;
    }
   
  /* Minimizers for the case there are more than one covars */

  gsl_vector *gsl_betas;
  gsl_multimin_function_fdf Q_b_fdf;
  const gsl_multimin_fdfminimizer_type *T_b;
  gsl_multimin_fdfminimizer *s_b;


  /* Minimizers for the case there is only one covar */
   
  const gsl_root_fdfsolver_type *T1_b;
  gsl_root_fdfsolver *s1_b;
  gsl_function_fdf Q1_b;


  /* Maximizing the Likelihood under no genetic component */
  double L0,*b0,*s_b0;
  b0=dvector(ped.ncovars);
  s_b0=dvector(ped.ncovars);


  for(i=0;i<ped.ncovars;i++)
    if(bpoints[i]!=0)
      {
	betas[i]=rand_unif_f(blims[i][0],blims[i][1]);
      }else
      betas[i]=blims[i][0];


  if( ped.ncovars > 1)
    {
  /* Initializing Minimizers for the case there are more than one covars */
      gsl_betas = gsl_vector_alloc (ped.ncovars);
      Q_b_fdf.f = &gsl_Q_null_beta_f;
      Q_b_fdf.df = &gsl_grad_Q_null_beta_f;
      Q_b_fdf.fdf = &gsl_both_Q_null_beta_f;
      Q_b_fdf.n =ped.ncovars ;
      Q_b_fdf.params = &pars;
      T_b = gsl_multimin_fdfminimizer_vector_bfgs;
      s_b = gsl_multimin_fdfminimizer_alloc (T_b,ped.ncovars);


      cblas_dcopy(ped.ncovars,betas,1,gsl_betas->data,1);
      fdf_mininize_f(gsl_betas,Q_b_fdf,s_b,.001,1000,TOL);
      L0=s_b->f;
      cblas_dcopy(ped.ncovars,s_b->x->data,1,b0,1);
 
  /* Initializing minimizer for the MCEM */

      gsl_betas = gsl_vector_alloc (ped.ncovars);
      Q_b_fdf.f = &gsl_Q_beta_f;
      Q_b_fdf.df = &gsl_grad_Q_beta_f;
      Q_b_fdf.fdf = &gsl_both_Q_beta_f;
      Q_b_fdf.n =ped.ncovars ;
      Q_b_fdf.params = &pars;
    }

  if( ped.ncovars == 1)
    {
   /* Initializing minimizers for the case there is only one covar */
      gsl_betas = gsl_vector_alloc (ped.ncovars);
      Q1_b.f = &gsl_one_grad_null_Q_beta_f;
      Q1_b.df = &null_one_hess_Q_beta_f;
      Q1_b.fdf = &gsl_one_both_hess_null_Q_beta_f;
      Q1_b.params = &pars;
      T1_b = gsl_root_fdfsolver_newton;
      /* 		    T1_b =gsl_root_fdfsolver_secant; */
      /*    	     T1_b =gsl_root_fdfsolver_steffenson ; */
      s1_b = gsl_root_fdfsolver_alloc (T1_b);


           
      cblas_dcopy(ped.ncovars,betas,1,gsl_betas->data,1);
      betas[0]=0;
      one_fdf_root_find_f(betas[0],Q1_b,s1_b,1000,TOL);
      b0[0]=gsl_root_fdfsolver_root (s1_b);
      L0=Q_beta_f(beta_hat);
      
   /* Initializing minimizer for MCEM */
      Q1_b.f = &gsl_one_grad_Q_beta_f;
      Q1_b.df = &one_hess_Q_beta_f;
      Q1_b.fdf = &gsl_one_both_hess_Q_beta_f;
      Q1_b.params = &pars;
    }
 
  if( ped.ncovars > 0)
    {
      /* St. Dev. of null estimates */
      HESS_Q_null_beta_f(Hb);
      inv_mat_f(ped.ncovars,Hb,Hb);
      for(i=0;i<ped.ncovars;i++)
	s_b0[i]=sqrt(Hb.mat[i][i]);
    }
  
  /* initializing the gradient and hessian of */
  /* the variance part of likelihood        */

  if(nsigmas>0)
    {
      grad_s=dvector(nsigmas);
      s_vars=dvector(nsigmas);
      sigmas_hat=dvector(nsigmas);
      Hs=alloc_DMATRIX(nsigmas,nsigmas);
      for(i=0;i<nsigmas;i++)
	for(j=0;j<nsigmas;j++)
	  Hs.mat[i][j]=0;
      for(i=0;i<nsigmas;i++)
	Hs.mat[i][i]=1.0;
      s++;
    }


  gsl_vector *gsl_sigmas;
  gsl_sigmas = gsl_vector_alloc (nsigmas);
  gsl_multimin_function_fdf Q_s_fdf;
  const gsl_multimin_fdfminimizer_type *T_s;
  gsl_multimin_fdfminimizer *s_s;
  
  
  Q_s_fdf.f = &gsl_Q_sigma_f;
  Q_s_fdf.df = &gsl_grad_Q_sigma_f;
  Q_s_fdf.fdf = &gsl_both_Q_sigma_f;
  Q_s_fdf.n =nsigmas ;
  Q_s_fdf.params = &pars;
  
  T_s = gsl_multimin_fdfminimizer_conjugate_fr;
  s_s = gsl_multimin_fdfminimizer_alloc (T_s,nsigmas);
  
  f1=0;
  f2=0;
 
  DMATRIX S_MC_b,S_MC_s;
  double t;
  /* MC variance matrix */
  
  S_MC_b=alloc_DMATRIX(ped.ncovars,ped.ncovars);
  S_MC_s=alloc_DMATRIX(nsigmas,nsigmas);
 

  int recycle=0, max_recycle=0;
  int MC_l,MC_u,MC_new;
  MC_l=0;
  MC_u=MC;
  double prod_null[ped.npeople];
  int iter=0,ks=0;
  int flag=1;
  double max_beta=200,max_sigma=100;

  double neigb=3, maxL=1e100,L;

  int generate=1,imax_count=0,imax_index=0;
  double chi_crit;
  int jb,js;
  double maxabspars=1000;

  /* Print On Screen  */
  if(screen==1)
    {
      for(i=0;i<10;i++)
	printf("=======\t");
      printf("\n");
      printf("\n");
      printf("Pedigree file:\t%s\n",pedfile);
      printf("Pedigree size:\t%3d\n",ped.npeople);
      printf("\n");
      for(i=0;i<10;i++)
	printf("=======\t");
      printf("\n");
      printf("\n");
      printf("Analysis file:\t%s\n",infofile);
      printf("Number of covariates:\t\t%3d\n",ped.ncovars);
      printf("Number of variance components:\t%3d\n",nsigmas);
      printf("Filenames of covariance matrices:\n");
      for(i=0;i<nsigmas;i++)
	printf("%1d) %s\n",i+1,matfiles[i]);
      printf("\n");
      for(i=0;i<10;i++)
	printf("=======\t");
      printf("\n");
      printf("\n");
      printf("MCEM information\n");
      printf("Burn-in iterations:\t\t\t\t%7d\n",BURN);
      printf("Max Importance Sampling iterations:\t\t%7d\n",maxite);
      printf("Initial MCMC sample size:\t\t\t%7d\n",MC);
      printf("Likelihood estimate MCMC sample size:\t\t%7d\n",MC_like);
      printf("Grid Likelihood estimate MCMC sample size:\t%7d\n",start_MC);
      printf("\n");
      for(i=0;i<10;i++)
	printf("=======\t");
      printf("\n");
      printf("\n");
      printf("Poisson sub-sampling tunning parameters\n");
      printf("nu=\t%7.3f\nb=\t%7.3f\n",nu,bpois);
      printf("\n");
      for(i=0;i<10;i++)
	printf("=======\t");
      printf("\n");
      printf("\n");
      printf("Convergence tunning parameters\n");
      printf("Delta1=\t%7.6g\nDelta2=\t%7.6g\n",deltas[1],deltas[2]);
      printf("\n");
      for(i=0;i<10;i++)
	printf("=======\t");
      printf("\n");
      printf("\n");
      printf("MLEs under no genetic model \n");
      printf("     -LogL  \t");
      for(i=0;i<ped.ncovars;i++)
	printf(" beta%1d \t   SD  \t",i);
      printf("\n");
      printf(" ======\t");
      printf(" ======\t");
      for(i=0;i<ped.ncovars;i++)
	printf(" ======\t ======\t");
      printf("\n");
      printf("%14.3f\t",L0);
      for(i=0;i<ped.ncovars;i++)
	printf("%7.4f\t%7.4f\t",b0[i],s_b0[i]);
      printf("\n");
      printf("\n");
      for(i=0;i<10;i++)
	printf("=======\t");
      printf("\n");
      fflush(stdout);

    }
  
  /* Print in file */
  
  for(i=0;i<10;i++)
    fprintf(out,"=======\t");
  fprintf(out,"\n");
  fprintf(out,"\n");
  fprintf(out,"Pedigree file:\t%s\n",pedfile);
  fprintf(out,"Pedigree size:\t%3d\n",ped.npeople);
  fprintf(out,"\n");
  for(i=0;i<10;i++)
    fprintf(out,"=======\t");
  fprintf(out,"\n");
  fprintf(out,"\n");
  fprintf(out,"Analysis file:\t%s\n",infofile);
  fprintf(out,"Number of covariates:\t\t%3d\n",ped.ncovars);
  fprintf(out,"Number of variance components:\t%3d\n",nsigmas);
  fprintf(out,"Filenames of covariance matrices:\n");
  for(i=0;i<nsigmas;i++)
   fprintf(out,"%1d) %s\n",i,matfiles[i]);
  fprintf(out,"\n");
  for(i=0;i<10;i++)
    fprintf(out,"=======\t");
  fprintf(out,"\n");
  fprintf(out,"\n");
  fprintf(out,"MCEM information\n");
  fprintf(out,"Burn-in iterations:\t\t\t\t%7d\n",BURN);
  fprintf(out,"Max Importance Sampling iterations:\t\t%7d\n",maxite);
  fprintf(out,"Initial MCMC sample size:\t\t\t%7d\n",MC);
  fprintf(out,"Likelihood estimate MCMC sample size:\t\t%7d\n",MC_like);
  fprintf(out,"Grid Likelihood estimate MCMC sample size:\t%7d\n",start_MC);
  fprintf(out,"\n");
  for(i=0;i<10;i++)
    fprintf(out,"=======\t");
  fprintf(out,"\n");
  fprintf(out,"\n");
  fprintf(out,"Poisson sub-sampling tunning parameters\n");
  fprintf(out,"nu=\t%7.3f\nb=\t%7.3f\n",nu,bpois);
  fprintf(out,"\n");
  for(i=0;i<10;i++)
    fprintf(out,"=======\t");
  fprintf(out,"\n");
  fprintf(out,"\n");
  fprintf(out,"Convergence tunning parameters\n");
  fprintf(out,"Delta1=\t%7.6g\nDelta2=\t%7.6g\n",deltas[1],deltas[2]);
    fprintf(out,"\n");
  for(i=0;i<10;i++)
    fprintf(out,"=======\t");
  fprintf(out,"\n");
  fprintf(out,"\n");
  fprintf(out,"MLEs under no genetic model \n");
  fprintf(out,"     -LogL  \t");
  for(i=0;i<ped.ncovars;i++)
    fprintf(out," beta%1d \t   SD  \t",i);
  fprintf(out,"\n");
  fprintf(out," ======\t");
  fprintf(out," ======\t");
  for(i=0;i<ped.ncovars;i++)
    fprintf(out," ======\t ======\t");
  fprintf(out,"\n");
  fprintf(out,"%14.3f\t",L0);
  for(i=0;i<ped.ncovars;i++)
    fprintf(out,"%7.4f\t%7.4f\t",b0[i],s_b0[i]);
  fprintf(out,"\n");
  fprintf(out,"\n");
  for(i=0;i<10;i++)
    fprintf(out,"=======\t");
  fprintf(out,"\n");
  fflush(out);


  int import_rep=1,neg_def=0,max_neg_def=3;
  int max_import_reps=2;
  double null_eps=1e-1;
  double var_vec[ped.ncovars+nsigmas];
  int zero_pars;
  
 RESTART_DUE_TO_NAN_INF:  ks++;
   for(i=0;i<ped.npeople;i++)
    XB[i]=prod_null[i]=0;

     if(ks > 4)
	{
	  printf("Error with starting point\n");
	  exit(1);
	}
 
  
      for(i=0;i<ped.ncovars;i++)
	if(bpoints[i]!=0)
	  {
	    betas[i]=rand_unif_f(blims[i][0],blims[i][1]);
	  }else
	    betas[i]=blims[i][0];

      for(i=0;i<nsigmas;i++)
	if(spoints[i]!=0)
	  {
	    sigmas[i]=rand_unif_f(slims[i][0],slims[i][1]);
	  }else
	    sigmas[i]=slims[i][0];



    /* Print On Screen  */
  if(screen==1)
    {
      printf("\n");
      printf("Starting Point\n");
      for(i=0;i<ped.ncovars;i++)
    printf("beta%1d  = %7.3f\n",i,betas[i]);
      for(i=0;i<nsigmas;i++)
	printf("sigma%1d = %7.3f\n",i,sigmas[i]);
      printf("\n");
      for(i=0;i<10;i++)
	printf("=======\t");
      printf("\n");
      for(i=0;i<10;i++)
	printf("=======\t");
      printf("\n");
      printf("\n");
      printf("\t\tBURN-IN\n");
      printf("\t\t=======\n");
      printf("\n");
      
      printf(" ITER \t");
      for(i=0;i<ped.ncovars;i++)
	printf(" beta%1d \t",i);
      for(i=0;i<nsigmas;i++)
	printf(" sigma%1d\t",i);
      printf("\n");
      printf(" ======\t");
      for(i=0;i<ped.ncovars;i++)
	printf(" ======\t");
      for(i=0;i<nsigmas;i++)
	printf(" ======\t");
      printf("\n");
      fflush(stdout);
   }



  /* Print in file */

  
  fprintf(out,"\n");
  fprintf(out,"Starting Point\n");
  for(i=0;i<ped.ncovars;i++)
    fprintf(out,"beta%1d  = %7.3f\n",i,betas[i]);
  for(i=0;i<nsigmas;i++)
    fprintf(out,"sigma%1d = %7.3f\n",i,sigmas[i]);
  fprintf(out,"\n");
  for(i=0;i<10;i++)
    fprintf(out,"=======\t");
  fprintf(out,"\n");
  for(i=0;i<10;i++)
    fprintf(out,"=======\t");
  fprintf(out,"\n");
  fprintf(out,"\n");
  fprintf(out,"\t\tBURN-IN\n");
  fprintf(out,"\t\t=======\n");
  fprintf(out,"\n");

  fprintf(out," ITER \t");
  for(i=0;i<ped.ncovars;i++)
    fprintf(out," beta%1d \t",i);
  for(i=0;i<nsigmas;i++)
    fprintf(out," sigma%1d\t",i);
  fprintf(out,"\n");
    fprintf(out," ======\t");
  for(i=0;i<ped.ncovars;i++)
    fprintf(out," ======\t");
  for(i=0;i<nsigmas;i++)
    fprintf(out," ======\t");
  fprintf(out,"\n");
  fflush(out);
	  

/*   while( flag ==1) */
    {
     
      
      W=MC;
      for(i=0;i<MC;i++)
	weights[i]=1;

      if(ped.ncovars>0)
	{
	  for(i=0;i<ped.ncovars;i++)
	    for(j=0;j<ped.ncovars;j++)
	      Hb.mat[i][j]=0;
	  
	  for(i=0;i<ped.ncovars;i++)
	    Hb.mat[i][i]=1.0;
	}
      for(i=0;i<nsigmas;i++)
	for(j=0;j<nsigmas;j++)
	  Hs.mat[i][j]=0;
      for(i=0;i<nsigmas;i++)
	Hs.mat[i][i]=1.0;

     iter=0;
      while(iter < BURN )
	{
	  iter++;
	  /*    generating the MCMC samples */
	  V_hat_f(sigmas,VS);
	  cholesky_f(VS.mat,Null_CHOL.mat,ped.npeople,&i);
	  DET_null=log_det_chol_inv_mat_f(ped.npeople,Null_CHOL,VSI_null);
	  if(ped.ncovars>0)
	    cov_logit_cond_like(betas,prod_null);
	  /* We use the poisson subsampling scheme to thin the MMC chain */

	  poiss_metropolis_componentwise_sample_f(MC_u-MC_l,1000,nu,bpois,prod_null,MC_U,null_weights,MC_l);

	  /* MLEs for beta_i */
	  if(ped.ncovars>1)
	    {
	      cblas_dcopy(ped.ncovars,betas,1,gsl_betas->data,1);
	      fdf_mininize_f(gsl_betas,Q_b_fdf,s_b,.001,100,TOL);
	      cblas_dcopy(ped.ncovars,s_b->x->data,1,betas,1);
	    }else
	      {
		if(ped.ncovars==1)
		  {
		    one_fdf_root_find_f(betas[0],Q1_b,s1_b,100,TOL);
		    betas[0]=gsl_root_fdfsolver_root (s1_b);
		  }
	      }


	   for(i=0;i<ped.ncovars;i++)
	     if(fabs(betas[i])>maxabspars)
	       betas[i]=0;

	   /* Check if estimates are NAN or INF */
	  
	   if(test_vec_nan_inf_f(ped.ncovars,betas)==1)
	     {
	       MC=100;
	       MC_u=100;
	       MC_l=0;
	       goto RESTART_DUE_TO_NAN_INF;
	     }
	  /* MLEs for sigma_i */
	  if(nsigmas>1)
	    {
	      MC_outer_f(MC_outer);
	      
	      cblas_dcopy(nsigmas,sigmas,1,gsl_sigmas->data,1);
	      fdf_mininize_f(gsl_sigmas,Q_s_fdf,s_s,.001,100,TOL);
	      cblas_dcopy(nsigmas,s_s->x->data,1,sigmas,1);
	    }else
	      {
		if(nsigmas==1)
		  {
		    MC_outer_f(MC_outer);
		    f2=max_single_Qs_f(sigmas,Hs);
		  }
	      }
	   for(i=0;i<nsigmas;i++)
	     if(fabs(sigmas[i])>maxabspars)
	       sigmas[i]=1;
	   /* Check if estimates are NAN or INF */
	  
	   if(test_vec_nan_inf_f(nsigmas,sigmas)==1)
	    {
	       MC=100;
	       MC_u=100;
	       MC_l=0;
	       goto RESTART_DUE_TO_NAN_INF;
	    }

      if(screen==1)
	{
	  /*      print on screen */
	  fprintf(stdout,"%3d\t",iter);
	  for(i=0;i<ped.ncovars;i++)
	    fprintf(stdout,"%7.4f\t",betas[i]);
	  for(i=0;i<nsigmas;i++)
	    fprintf(stdout,"%7.4f\t",fabs(sigmas[i]));
	  fprintf(stdout,"\n");
	  fflush(stdout);
	}
      /*      print on file */
      fprintf(out,"%3d\t",iter);
      for(i=0;i<ped.ncovars;i++)
	fprintf(out,"%7.4f\t",betas[i]);
      for(i=0;i<nsigmas;i++)
	fprintf(out,"%7.4f\t",fabs(sigmas[i]));
      fprintf(out,"\n");
      fflush(out);
    
    }
       

/* restart Is because Covariance matrix was negative definite */

    RESTART_DUE_TO_NEGATIVE_DEF: neg_def++;

      /*      print on screen */

  if(screen==1)
    {
      printf("\n");
      for(i=0;i<10;i++)
	printf("=======\t");
      printf("\n");
      for(i=0;i<10;i++)
	printf("=======\t");
      printf("\n");
      printf("\n");
      printf("\tImportance Sampling\n");
      printf("\t===================\n");
      printf("\n");
      
      printf(" ITER \tMC_size\t Q_tot \t");
      for(i=0;i<ped.ncovars;i++)
	printf(" beta%1d\t MC_SD \t",i);
      for(i=0;i<nsigmas;i++)
	printf(" sigma%1d\t MC_SD \t",i);
      printf("\n");
      for(i=0;i<3;i++)
	printf("=======\t");
      for(i=0;i<ped.ncovars;i++)
	printf("=======\t=======\t");
      for(i=0;i<nsigmas;i++)
	printf("=======\t=======\t");
      printf("\n");
      fflush(stdout);
    }
  
  /*      print in file */
  
  fprintf(out,"\n");
  for(i=0;i<10;i++)
    fprintf(out,"=======\t");
  fprintf(out,"\n");
  for(i=0;i<10;i++)
    fprintf(out,"=======\t");
  fprintf(out,"\n");
  fprintf(out,"\n");
  fprintf(out,"\tImportance Sampling\n");
  fprintf(out,"\t==================\n");
  fprintf(out,"\n");
  
  fprintf(out," ITER \tMC_size\t Q_tot \t");
  for(i=0;i<ped.ncovars;i++)
    fprintf(out," beta%1d\t MC_SD \t",i);
  for(i=0;i<nsigmas;i++)
    fprintf(out," sigma%1d\t MC_SD \t",i);
  fprintf(out,"\n");
  for(i=0;i<3;i++)
    fprintf(out,"=======\t");
  for(i=0;i<ped.ncovars;i++)
    fprintf(out,"=======\t=======\t");
  for(i=0;i<nsigmas;i++)
    fprintf(out,"=======\t=======\t");
  fprintf(out,"\n");
  fflush(out);
   
      cont=s;
      iter=0;
      MC_l=0;
      MC_u=MC;
      chi_crit=gsl_cdf_chisq_Qinv (MC_alpha,nsigmas+ped.ncovars);
 

      cblas_dcopy(ped.ncovars,betas,1,null_betas,1);
      cblas_dcopy(nsigmas,sigmas,1,null_sigmas,1);
      V_hat_f(null_sigmas,VS);
      cholesky_f(VS.mat,Null_CHOL.mat,ped.npeople,&i);
      DET_null=log_det_chol_inv_mat_f(ped.npeople,Null_CHOL,VSI_null);
      if(ped.ncovars >0)
	cov_logit_cond_like(null_betas,prod_null);

     while( iter < maxite && conv > 0)
	{
	  cont=s;
	  iter++;
	  
	  if(generate==1)
	    {
	      poiss_metropolis_componentwise_sample_f(MC_u-MC_l,1000,nu,bpois,prod_null,MC_U,null_weights,MC_l);
	      log_probs_samples_f(MC_u,null_weights,null_weights,MC_l);

	      MC_l=MC_u;
	      generate=0;
	    }
	  
	  if(iter > 1)
	    {
	      if(ped.ncovars >0)
		cov_logit_cond_like(betas,XB);
	      log_weights_samples_f(XB,null_weights,weights);
	    }

	  /* MLEs for beta_i */
	  if(ped.ncovars>1)
	    {
	      cblas_dcopy(ped.ncovars,betas,1,gsl_betas->data,1);
	      fdf_mininize_f(gsl_betas,Q_b_fdf,s_b,.001,100,TOL);
	      f1=s_b->f;
	      HESS_Q_beta_f(Hb);
	      inv_mat_f(ped.ncovars,Hb,Hb);

	      /* check convergence max{|b_i^{k}-b_i^{k+1}|/(|b_i^{k}|+d1)} < d2 */
	      /* see Booth & Hobert (1999) */
	      
	      cont-=BH_stopping_rule_f(ped.ncovars,betas,s_b->x->data,deltas[1],deltas[2]);
	      /* estimating the MC error covariance matrix for the beta companents*/
	      beta_MC_error_var_mat_f(XB,Hb,S_MC_b);
	      chi_b= chi_square_f(ped.ncovars,s_b->x->data,betas,S_MC_b);
	      cblas_dcopy(ped.ncovars,s_b->x->data,1,betas,1);
	    }else
	      {
		if(ped.ncovars==1)
		  {
		    one_fdf_root_find_f(betas[0],Q1_b,s1_b,100,TOL);

		    /* check convergence max{|b_i^{k}-b_i^{k+1}|/(|b_i^{k}|+d1)} < d2 */
		    /* see Booth & Hobert (1999) */
		    beta_hat[0]=gsl_root_fdfsolver_root (s1_b);
		    f1=Q_beta_f(beta_hat);
		    Hb.mat[0][0]=1/one_hess_Q_beta_f(beta_hat[0],pars);

		    cont-=BH_stopping_rule_f(ped.ncovars,beta_hat,betas,deltas[1],deltas[2]);
		    /* estimating the MC error covariance matrix for the beta companents*/
		    beta_MC_error_var_mat_f(XB,Hb,S_MC_b);
		    chi_b= chi_square_f(ped.ncovars,beta_hat,betas,S_MC_b);
		    betas[0]=beta_hat[0];
		  }
	      }
	   /* Check if estimates are NAN or INF */
	  
	   if(test_vec_nan_inf_f(ped.ncovars,betas)==1)
	    {
	       MC=100;
	       MC_u=100;
	       MC_l=0;
	     goto RESTART_DUE_TO_NAN_INF;
	    }
	  /* MLEs for sigma_i */
	  if(nsigmas>1)
	    {
	      MC_outer_f(MC_outer);
	      
	      cblas_dcopy(nsigmas,sigmas,1,gsl_sigmas->data,1);
	      fdf_mininize_f(gsl_sigmas,Q_s_fdf,s_s,.001,100,TOL);
	      hessian_Q_sigma_f(s_s->x->data,s_s->gradient->data,Hs);
	      inv_mat_f(nsigmas,Hs,Hs);
	      f2=s_s->f;
	      /* check convergence max{|s_i^{k}-s_i^{k+1}|/(|s_i^{k}|+d1)} < d2 */
	      /* see Booth & Hobert (1999) */
	      cont-=BH_stopping_rule_f( nsigmas,sigmas,s_s->x->data,deltas[1],deltas[2]);
	  /* estimating the MC error covariance matrix */

	      sigma_MC_error_var_mat_f(s_s->x->data,Hs,S_MC_s);
	      chi_s=chi_square_f(nsigmas,s_s->x->data,sigmas,S_MC_s);
	      cblas_dcopy(nsigmas,s_s->x->data,1,sigmas,1);
	    }else
	      {
		if(nsigmas==1)
		  {
		    MC_outer_f(MC_outer);
		    f2=max_single_Qs_f(sigma_hat,Hs);
		    set_mat_single_Q_s_f(sigma_hat);
		    f2+=.5*(DET + ped.npeople*ln2pi);
		    /* check convergence max{|s_i^{k}-s_i^{k+1}|/(|s_i^{k}|+d1)} < d2 */
		    /* see Booth & Hobert (1999) */
		    cont-=BH_stopping_rule_f( nsigmas,sigmas,sigma_hat,deltas[1],deltas[2]);
		    /* estimating the MC error covariance matrix */
		    
		    sigma_MC_error_var_mat_f(sigma_hat,Hs,S_MC_s);
		    chi_s=chi_square_f(nsigmas,sigma_hat,sigmas,S_MC_s);
		    cblas_dcopy(nsigmas,sigma_hat,1,sigmas,1);
		  }
	      }

	   /* Check if estimates are NAN or INF */
	  
	   if(test_vec_nan_inf_f(nsigmas,sigmas)==1)
	    {
	       MC=100;
	       MC_u=100;
	       MC_l=0;
	     goto RESTART_DUE_TO_NAN_INF;
	    }
	  f=f1+f2;
	  
     if(screen==1)
	{
	  /* print on screen */
	  fprintf(stdout,"%5d\t%7d\t%6.3f ",iter,MC,f);
	  
	  for(i=0;i<ped.ncovars;i++)
	    fprintf(stdout,"%7.4f\t%7.5f\t",betas[i],sqrt(S_MC_b.mat[i][i]/MC));
	  for(i=0;i<nsigmas;i++)
	    fprintf(stdout,"%7.4f\t%7.5f\t",fabs(sigmas[i]),sqrt(S_MC_s.mat[i][i]/MC));
	  fprintf(stdout,"\n");
	  fflush(stdout);
	}
      
      /* print on file */
      fprintf(out,"%5d\t%7d\t%6.3f ",iter,MC,f);
      for(i=0;i<ped.ncovars;i++)
	fprintf(out,"%7.4f\t%7.5f\t",betas[i],sqrt(Hb.mat[i][i]/MC));
      for(i=0;i<nsigmas;i++)
	fprintf(out,"%7.4f\t%7.5f\t",fabs(sigmas[i]),sqrt(Hs.mat[i][i]/MC));
      fprintf(out,"\n");
      fflush(out);
      
	  /* Deciding to increase the sample size or not */
	  incre=.5;
	  chi=chi_s+chi_b;
	  if(MC==MAXMC && chi < chi_crit)
	    {
	  if(screen==1)
	    {
	      printf("MAXEDOUT\t");
	    }
	      imax_count++;
	      conv=-1;
	    }
	  /*      Check if the parameters used for the generation of the Importance sample are closed to the current estimates. If not regenerate the MC sample using the current estimates as null  */
	  i=max_rel_test_vectors(nsigmas,sigmas,null_sigmas,null_eps,.4) + max_rel_test_vectors(ped.ncovars,betas,null_betas,null_eps,.4);

      /* Checking if convergence has been reached */
      /* One condition is that the MCEM is not swamped by MC error */
      /* This is why we require that chi > chi_crit */
      /* We can also require that the MC size be at least MC_low before
	 the MCEM can stop, in order to avoid premature stopping */
      
	  if(cont == 0 && MC > low_MC && chi > chi_crit)
	    {
	      conv--;
	    }else
	      {
		if(conv != -1)
		  conv=consec;
	      }

	  if(i<2 && conv > 0)
	    {
	  /* if true, then MCEM drifted away from neigbourhood
	     of the null estimates, so we need to discart the
	     current MC sample and generate a new one */

	      cblas_dcopy(nsigmas,sigmas,1,null_sigmas,1);
	      cblas_dcopy(ped.ncovars,betas,1,null_betas,1);
	      V_hat_f(null_sigmas,VS);
	      cholesky_f(VS.mat,Null_CHOL.mat,ped.npeople,&i);
	      DET_null=log_det_chol_inv_mat_f(ped.npeople,Null_CHOL,VSI_null);
	      if(ped.ncovars >0)
		cov_logit_cond_like(null_betas,prod_null);
	      generate=1;
	      MC_l=0;
	  if(screen==1)
	    {
	      printf(" Renewed at %4d\n",iter);
	    }
	    }

	  if(chi < chi_crit && MC < MAXMC && conv > 0)
	    {
	      if(chi > .001)
		{
		  MC_new=(int)ceil(chi_crit/(chi/MC));
		}else
		  {
		    MC_new=(1.0+incre )*MC;
		  }
	      if(MC_new > (int)ceil((1.0+ incre)*MC))
		{
		  MC=(int)ceil((1.0+ incre)*MC);
		}else
		  MC=MC_new;
   
	      if(MC >MAXMC)
		MC=MAXMC;

	      MC_u=MC;
	      generate=1;
	    }

     if(conv < 0 && import_rep < max_import_reps)
       {
	  /* if the MAXMC size has been reached and we still need to
	     increase it, then we restart the IS-MCEM with starting
	     point the current estimates, and initital MC size of 1000  */
  
	 import_rep++;
	 cblas_dcopy(nsigmas,sigmas,1,null_sigmas,1);
	 cblas_dcopy(ped.ncovars,betas,1,null_betas,1);
	 V_hat_f(null_sigmas,VS);
	 cholesky_f(VS.mat,Null_CHOL.mat,ped.npeople,&i);
	 DET_null=log_det_chol_inv_mat_f(ped.npeople,Null_CHOL,VSI_null);
	 if(ped.ncovars >0)
	   cov_logit_cond_like(null_betas,prod_null);
	 generate=1;
	 MC_l=0;
	 MC=10000;
	 conv=consec;
	  if(screen==1)
	    {
	      printf(" Renewed Importance at %4d\n",iter);
	    }
       }
  
	}
    }
  
/*     } */

  /* Estimating the Likelihood at the MLEs and the SD for the parameters */

  DMATRIX HJ;
  HJ=alloc_DMATRIX(ped.ncovars+nsigmas,ped.ncovars+nsigmas);

/* Checking to see if any of the var components is zero resulting in a singular matrix */
    zero_pars=0;
    for(i=0;i<nsigmas;i++)
      if(abs(sigmas[i]) < .001)
	zero_pars++;



    if(zero_pars > 0 )
      {
	for(i=0;i<nsigmas+ped.ncovars;i++)
	  HJ.mat[i][i]=0;
	if(screen==1)
	    printf(" Singular Var Mat \n");
        goto SINGULAR_MAT;
      }

 RESAMPLE_DUE_TO_NEGATIVE_DEF: neg_def++;
    joint_cov_f(betas,sigmas,Hb,Hs,grad_s,HJ);

  for(i=0;i<ped.ncovars+nsigmas;i++)
    var_vec[i]=sqrt(HJ.mat[i][i]);

     if(test_vec_nan_inf_f(ped.ncovars+nsigmas,var_vec)==1 && neg_def <max_neg_def )
       {
	 import_rep++;
	 cblas_dcopy(nsigmas,sigmas,1,null_sigmas,1);
	 cblas_dcopy(ped.ncovars,betas,1,null_betas,1);
	 V_hat_f(null_sigmas,VS);
	 cholesky_f(VS.mat,Null_CHOL.mat,ped.npeople,&i);
	 DET_null=log_det_chol_inv_mat_f(ped.npeople,Null_CHOL,VSI_null);
	 if(ped.ncovars >0)
	   cov_logit_cond_like(null_betas,prod_null);
	 generate=1;
	 MC_l=0;
	 MC=10000;
	 conv=consec;

	  if(generate==1)
	    {
	      poiss_metropolis_componentwise_sample_f(MC_u-MC_l,1000,nu,bpois,prod_null,MC_U,null_weights,MC_l);
	      log_probs_samples_f(MC_u,null_weights,null_weights,MC_l);

	      MC_l=MC_u;
	      generate=0;
	    }
	  for(i=0;i<MC;i++)
	    weights[i]=1;

	  if(screen==1)
	    {
	      printf(" Recalculation of hessian via resampling due to Negative definite COV MAT at %4d\n",iter);
	    }


	  goto RESAMPLE_DUE_TO_NEGATIVE_DEF;
       }

 SINGULAR_MAT: i=0;

  f=loglike_f(betas,sigmas,MC_like);

if(isinf(f))
f=0;

  if(ped.ncovars==0)
     {
	L0=0;
      }

  if(screen==1)
    {
/*       print on screen  */
      printf("\n");
      for(i=0;i<10;i++)
	printf("=======\t");
      printf("\n");
      printf("\n");
      printf("\t MAXIMUM\n");
      printf("\t=========\n");
      printf("\n");
      
      printf(" Conv \t ITER \tMC_size\t      LogL    \t     LogL0    \t-2logLR\t");
      for(i=0;i<ped.ncovars;i++)
	printf(" beta%1d    SD  ",i);
      for(i=0;i<nsigmas;i++)
	printf(" sigma%1d    SD  ",i);
      printf("\n");
      for(i=0;i<3;i++)
      printf(" ======\t");
     for(i=0;i<2;i++)
      printf(" ==============\t");
      printf(" ======\t");
      for(i=0;i<ped.ncovars;i++)
	printf("======= =======\t");
      for(i=0;i<nsigmas;i++)
	printf("======= =======\t");
      for(i=0;i<ped.ncovars;i++)
	printf("======= =======\t");
       printf("\n");
       if(conv==0)
	 {
	   printf(" Yes \t");
	 }else
	  printf("  No  \t");
       printf("%7d\t%7d\t%14.6f\t%14.6f\t%7.2f\t",
              iter,MC,f,f1,2*(f1-f));

      for(i=0;i<ped.ncovars;i++)
	fprintf(stdout,"%7.4f\t%7.5f\t",betas[i],sqrt(HJ.mat[i][i]));
      for(i=0;i<nsigmas;i++)
	fprintf(stdout,"%7.4f\t%7.5f\t",fabs(sigmas[i]),sqrt(HJ.mat[i+ped.ncovars][i+ped.ncovars]));
      printf("\n");
      for(i=0;i<10;i++)
	printf("=======\t");
      printf("\n");
      fflush(stdout);

    }
/*       print in file  */
      fprintf(out,"\n");
      for(i=0;i<10;i++)
	fprintf(out,"=======\t");
      fprintf(out,"\n");
      fprintf(out,"\n");
      fprintf(out,"\t MAXIMUM\n");
      fprintf(out,"\t=========\n");
      fprintf(out,"\n");
      
      fprintf(out," Conv \t ITER \tMC_size\t      LogL    \t     LogL0    \t-2logLR\t");
      for(i=0;i<ped.ncovars;i++)
	fprintf(out," beta%1d    SD  ",i);
      for(i=0;i<nsigmas;i++)
	fprintf(out," sigma%1d    SD  ",i);
      fprintf(out,"\n");
      for(i=0;i<3;i++)
	fprintf(out," ======\t");
      for(i=0;i<2;i++)
	fprintf(out," ==============\t");
      fprintf(out," ======\t");
      for(i=0;i<ped.ncovars;i++)
	fprintf(out,"======= =======\t");
      for(i=0;i<nsigmas;i++)
	fprintf(out,"======= =======\t");
      for(i=0;i<ped.ncovars;i++)
	fprintf(out,"======= =======\t");
       fprintf(out,"\n");
       if(conv==0)
	 {
	   fprintf(out," Yes \t");
	 }else
	 fprintf(out,"  No  \t");
       fprintf(out,"%7d\t%7d\t%14.6f\t%14.6f\t%7.2f\t",
              iter,MC,f,L0,2*(L0-f));
  
       for(i=0;i<ped.ncovars;i++)
	 fprintf(out,"%7.4f\t%7.5f\t",betas[i],sqrt(HJ.mat[i][i]));
       for(i=0;i<nsigmas;i++)
	 fprintf(out,"%7.4f\t%7.5f\t",fabs(sigmas[i]),sqrt(HJ.mat[i+ped.ncovars][i+ped.ncovars]));
       fprintf(out,"\n");
       for(i=0;i<10;i++)
	 fprintf(out,"=======\t");
       fprintf(out,"\n");
       fflush(out);

/*   put_seeds("seedmorgan"); */
  return 0;
}
       




/*################################################################*/
/*################################################################*/
int ped_check_f(char *pedfile)
{
  int duplicate_cov=0,i,j,p,id,n=ped.ncovars,intercept_flag=0;
  int **ident_covs;
  double id_eps=1e-3;
  ident_covs=imatrix(n,n);

  /* checking if intercept covariate provided*/
  if(ped.ncovars  > 1)
    {

      for(i=0;i<n;i++)
	{
	  id=0;
	  for(p=0;p<ped.npeople;p++)
	    if(fabs(ped.covariates.mat[p][i]-1.0)<id_eps)
	      id++;
/* 	  printf("i= %3d\t id= %3d\n",i,id); */
	  if(id == ped.npeople)
	    intercept_flag=1;
	}
      if(intercept_flag == 0)
	{
	  printf("<<<<<<<<<<<< Error >>>>>>>>>>>>\n");
	  printf("There is no Intercept covariate. Intercept is required when there are more than 1 covariates.\n");
	  exit(1);
	}

      /* Checking Duplicate Covariates */

      for(i=0;i<n;i++)
	{
	  for(j=i+1;j<n;j++)
	    {
/* 	  printf("i= %3d\t j= %3d\n",i,j); */
	      ident_covs[i][j]=0;
	      id=0;
	      for(p=0;p<ped.npeople;p++)
		if(fabs(ped.covariates.mat[p][i] - ped.covariates.mat[p][j])<id_eps) 
		  id++;
	      if(id == ped.npeople)
		{
		  duplicate_cov=1;
		  ident_covs[i][j]=1;
		}
/* 	      printf("%3d\t%3d\t%3d\t%3d\t%3d\n",i,j,id,duplicate_cov,ident_covs[i][j]); */
	    }
	}
      if(duplicate_cov == 1)
	{
	  printf("<<<<<<<<<<<< Error >>>>>>>>>>>>\n");
	  printf("The following pairs of covariates are (nearly) identical resulting in a singular matrix:\n");
	  for(i=0;i<n;i++)
	    for(j=i+1;j<n;j++)
	      if(ident_covs[i][j]==1)
		printf("%1d and %1d\n",i+1,j+1);
	  exit(1);
	}

    }


}

int test_vec_nan_inf_f(int d,double *vec)
{
  int i,T=0;

  for(i=0;i<d;i++)
    {
      T+=isnan(vec[i]);
      T+=isinf(vec[i]);
    }

  if(T>0)
    T=1;

  return T;
}

  

/*################################################################*/

double gsl_one_Q_beta_f(double v, void *params)
{
  double b[1]={v};
  return Q_beta_f(b);
}

double gsl_one_grad_Q_beta_f(double v, void *params)
{
  double b[1]={v},df[1]={0};
  grad_Q_beta_f(b,df);
  return df[0];
}

void gsl_one_both_Q_beta_f(double v, void *params,double *f,double *df)
{
  double b[1]={v},df1[1]={0};
  grad_Q_beta_f(b,df1);
  *f = Q_beta_f(b);
  *df=df1[0];
}
double gsl_Q_beta_f(const gsl_vector *v, void *params)
{
  return Q_beta_f(v->data);
}
void gsl_grad_Q_beta_f(const gsl_vector *v, void *params,gsl_vector *df)
{
 grad_Q_beta_f(v->data,df->data);
/*  print_vec_f(ped.ncovars,df->data,"%7.4f\t",0); */

}

void gsl_both_Q_beta_f(const gsl_vector *v, void *params,double *f,gsl_vector *df)
{
  gsl_grad_Q_beta_f(v,params,df);
  *f = gsl_Q_beta_f(v,params);

}



/* double gsl_Q_beta_f(const gsl_vector *v, void *params) */
/* { */
/* /\*   printf("%7.3f\n",Q_beta_f(v->data)); *\/ */
/*   return Q_beta_f(v->data); */
/* } */
/* void gsl_grad_Q_beta_f(const gsl_vector *v, void *params,gsl_vector *df) */
/* { */
/*   grad_Q_beta_f(v->data,df->data); */
/* /\*  print_vec_f(ped.ncovars,df->data,"%7.4f\t",0); *\/ */

/* } */

/* void gsl_both_Q_beta_f(const gsl_vector *v, void *params,double *f,gsl_vector *df) */
/* { */
/*   gsl_grad_Q_beta_f(v,params,df); */
/*   *f = gsl_Q_beta_f(v,params); */
/*   printf("ok\n"); */
/*  print_vec_f(ped.ncovars,df->data,"%7.4f\t",0); */

/* } */


double gsl_Q_sigma_f(const gsl_vector *v, void *params)
{
  return Q_sigma_f(v->data);
}

void gsl_grad_Q_sigma_f(const gsl_vector *v, void *params,gsl_vector *df)
{
  grad_Q_sigma_f(v->data,df->data);
}
void gsl_both_Q_sigma_f(const gsl_vector *v, void *params,double *f,gsl_vector *df)
{
  grad_Q_sigma_f(v->data,df->data);
  *f = Q_sigma_f(v->data);
}




double one_hess_Q_beta_f(double beta, void *params)
{
  /* The hessian of the covariate part of the Q function maximized */
  /* under the MCEM                                                */ 
  int i,m;
  double t,h,c;
  double H=0;

  cov_logit_cond_like(&beta,XB);

  for(i=0;i<ped.npeople;i++)
    {
      c=0;
      for(m=0;m<MC;m++)
	{
	  t=exp(XB[i]+MC_U.mat[m][i]);
	  h= t/pow((1+t),2);
	  c-= weights[m]*h;
         }
      H+=c*ped.covariates.mat[i][0]*ped.covariates.mat[i][0];
      
    }
  H/=-W;
  return H;
}

void gsl_one_both_hess_Q_beta_f(double v, void *params,double *f,double *df)
{
  double b[1]={v},df1[1]={0};
  grad_Q_beta_f(b,df1);
  *f = df1[0];
  *df=one_hess_Q_beta_f(v,params);
}


int joint_cov_f(double *betas, double *sigmas,DMATRIX Hb,DMATRIX Hs,double *grad_s,DMATRIX S)
{
  int i,j,k;
  double b=0,T,D,c=1.0/W;
  double u[ped.npeople];
  double grad_b[ped.ncovars];
  DMATRIX Hbs;
  if(ped.ncovars > 0 && nsigmas>0)
    Hbs=alloc_DMATRIX(ped.ncovars,nsigmas); 

  for(i=0;i<nsigmas;i++)
    for(j=0;j<nsigmas;j++)
      Hs.mat[i][j]=0;
/*   print_mat_f(nsigmas,nsigmas,Hs.mat,"%7.3g\t",0); */

  if(ped.ncovars > 0)
    HESS_Q_beta_f(Hb);
  if(nsigmas>0)
    hessian_Q_sigma_f(sigmas,grad_s,Hs);
/*   print_mat_f(ped.ncovars,ped.ncovars,Hb.mat,"%7.3g\t",0); */
/*   print_mat_f(nsigmas,nsigmas,Hs.mat,"%7.3g\t",0); */
/*   print_mat_f(nsigmas,nsigmas,Hs.mat,"%7.3g\t",0); */
 
  for(i=0;i<ped.ncovars;i++)
    for(j=0;j<=i;j++)
      S.mat[i][j]=S.mat[j][i]=Hb.mat[i][j];

  for(i=0;i<nsigmas;i++)
    for(j=0;j<=i;j++)
      S.mat[ped.ncovars+i][ped.ncovars+j]=S.mat[ped.ncovars+j][ped.ncovars+i]=Hs.mat[i][j];
/*   print_mat_f(ped.ncovars+nsigmas,ped.ncovars+nsigmas,S.mat,"%7.3g\t",0); */
  
 for(j=0;j<nsigmas;j++)
    {
      if(fabs(sigmas[j])<.0001)
	sigmas[j]=.0001;
      T=0;
      for(i=0;i<ped.npeople;i++)
	T+=GI_mats[j].mat[i][i];

      cblas_dsymm(CblasRowMajor,CblasRight,CblasUpper,ped.npeople,ped.npeople,1.0,VSI.arr,ped.npeople,GI_mats[j].arr,ped.npeople,0.0,temp_MAT.arr,ped.npeople);
      for(i=0;i<MC;i++)
	{
	  cblas_dsymv(CblasRowMajor,CblasUpper,ped.npeople,1,temp_MAT.arr,ped.npeople,MC_U.mat[i],1,0,u,1);
	  grads[i][j]=-sigmas[j]*(-T + cblas_ddot(ped.npeople,MC_U.mat[i],1,u,1));
	}
    }


  if(ped.ncovars > 0)
    for(i=0;i<MC;i++)
      {
	if(i>0)
	  b=1;
	grad_logit_cond_like(XB,MC_U.mat[i],grad_b);
	
	/*       for(j=0;j<nsigmas;j++) */
/* 	grads[i][j]=j+3; */
/*       for(j=0;j<ped.ncovars;j++) */
/* 	grad_b[j]=j+1; */
/*       weights[i]=1; */
	
	cblas_dgemm(CblasRowMajor,CblasTrans,CblasNoTrans,nsigmas,nsigmas,1,weights[i],grads[i],nsigmas,grads[i],nsigmas,b,Hs.arr,nsigmas);
	cblas_dgemm(CblasRowMajor,CblasTrans,CblasNoTrans,ped.ncovars,ped.ncovars,1,weights[i],grad_b,ped.ncovars,grad_b,ped.ncovars,b,Hb.arr,ped.ncovars);
	cblas_dgemm(CblasRowMajor,CblasTrans,CblasNoTrans,ped.ncovars,nsigmas,1,weights[i],grad_b,ped.ncovars,grads[i],nsigmas,b,Hbs.arr,nsigmas);
	
      }
  


  for(i=0;i<ped.ncovars;i++)
    for(j=i;j<ped.ncovars;j++)
      S.mat[i][j]-=(Hb.mat[i][j]/W);

  for(i=0;i<nsigmas;i++)
    for(j=i;j<nsigmas;j++)
      S.mat[ped.ncovars+i][ped.ncovars+j]-=(Hs.mat[i][j]/W);

  for(i=0;i<ped.ncovars;i++)
    for(j=0;j<nsigmas;j++)
       S.mat[i][ped.ncovars+j]=(Hbs.mat[i][j]/W);

/*  for(i=0;i<nsigmas*nsigmas;i++) */
/*    S.arr[i]/=W; */
/* /\*  new_inv_mat_f(nsigmas,S,S); *\/ */
/*   print_mat_f(ped.ncovars,ped.ncovars,Hb.mat,"%7.3g\t",0); */
/*   print_mat_f(nsigmas,nsigmas,Hs.mat,"%7.3g\t",0); */
/*   print_mat_f(ped.ncovars,nsigmas,Hbs.mat,"%7.3g\t",0); */
/*   print_mat_f(ped.ncovars+nsigmas,ped.ncovars+nsigmas,S.mat,"%7.3g\t",0); */
  inv_mat_f(ped.ncovars+nsigmas,S,S);
/*   print_mat_f(ped.ncovars+nsigmas,ped.ncovars+nsigmas,S.mat,"%7.3g\t",0); */

/*  cblas_dsymm(CblasRowMajor,CblasLeft,CblasUpper,nsigmas,nsigmas,1,H.arr,nsigmas,S.arr,nsigmas,0.0,temp_MAT.arr,nsigmas); */
/*   cblas_dsymm(CblasRowMajor,CblasRight,CblasUpper,nsigmas,nsigmas,1.0,H.arr,nsigmas,temp_MAT.arr,nsigmas,0.0,S.arr,nsigmas); */

/* /\*  print_mat_f(nsigmas,nsigmas,S.mat,"%40.38g\t",0); *\/ */

/*  new_inv_mat_f(nsigmas,S,S); */

  return 1;
}



/*################################################################*/
double null_one_hess_Q_beta_f(double beta, void *params)
{
  /* The hessian of the covariate part of the Q function maximized */
  /* under the MCEM                                                */ 
  int i,m;
  double t,h,c;
  double H=0;

  cov_logit_cond_like(&beta,XB);

  for(i=0;i<ped.npeople;i++)
    {
      t=exp(XB[i]);
      c= t/pow((1+t),2);
      H+=c*ped.covariates.mat[i][0]*ped.covariates.mat[i][0];
      
    }
  return H;
}



double gsl_one_grad_null_Q_beta_f(double v, void *params)
{
  double b[1]={v},df[1]={0};
  grad_Q_null_f(b,df);
  return df[0];
}


void gsl_one_both_hess_null_Q_beta_f(double v, void *params,double *f,double *df)
{
  double b[1]={v},df1[1]={0};
  grad_Q_null_f(b,df1);
  *f = df1[0];
  *df=null_one_hess_Q_beta_f(v,params);
}




double gsl_Q_null_beta_f(const gsl_vector *v, void *params)
{
  return log_Q_null_f(v->data);
}
void gsl_grad_Q_null_beta_f(const gsl_vector *v, void *params,gsl_vector *df)
{
  grad_Q_null_f(v->data,df->data);

}

void gsl_both_Q_null_beta_f(const gsl_vector *v, void *params,double *f,gsl_vector *df)
{
  gsl_grad_Q_null_beta_f(v,params,df);
  *f = gsl_Q_null_beta_f(v,params);

}

int HESS_Q_null_beta_f(DMATRIX H)
{
  /* The hessian of the covariate part of the Q function maximized */
  /* under the assumption of no genetic component */   
  int i,m,j,k;
  double t,h,dh,dh2,c,y;
  double temp[ped.npeople];

  for(j=0;j<ped.ncovars;j++)
    {
      H.mat[j][j]=0;
      for(k=0;k<j;k++)
        H.mat[j][k]=H.mat[k][j]=0;
    }
   for(i=0;i<ped.npeople;i++)
     {
       t=exp(XB[i]);
       c= t/pow((1+t),2);
       for(j=0;j<ped.ncovars;j++)
         {
           H.mat[j][j]+=c*ped.covariates.mat[i][j]*ped.covariates.mat[i][j];
           for(k=0;k<j;k++)
             H.mat[j][k]+=c*ped.covariates.mat[i][j]*ped.covariates.mat[i][k];
         }
          
     }
   for(j=0;j<ped.ncovars;j++)
     for(k=0;k<j;k++)
       H.mat[k][j]=H.mat[j][k];
  return 1;
}











int Qb_grid_loglike_f(double **lims,int *points)
{
  int i,j,status=0,max_i=0;
  double steps[ped.ncovars];
  double betas[ped.ncovars];
  int indexes[ped.ncovars];
  double L;
  FILE *out;
  out=open_f("QB.txt",'w');
  j=1;
  for(i=0;i<ped.ncovars;i++)
    {
      j*=points[i];
      indexes[i]=0;
      steps[i]=0;
      if(points[i] > 1)
	steps[i]=(lims[i][1]-lims[i][0])/(points[i]-1);
    }

  status=0;
  for(i=0;i<ped.ncovars;i++)
    indexes[i]=0;

  while(status ==0)
    {
      for(i=0;i<ped.ncovars;i++)
	betas[i]=lims[i][0]+indexes[i]*steps[i];
      L=Q_beta_f(betas);
      for(i=0;i<ped.ncovars;i++)
	fprintf(out,"%7.3f\t",betas[i]);
      fprintf(out,"%10.7g\n",L);
      status=update1_indexes_f(ped.ncovars,indexes,points,0);
    }

  return 1;
}
/*################################################################*/

int update1_indexes_f(int n,int *indexes, int *max_index, int s)
{
  int i,status=0;

  indexes[n-1]++;
  for( i=n-2;i>=0;i--)
    if(indexes[i+1] >= max_index[i+1])
      {
	indexes[i+1]=s;
	indexes[i]++;
      }
  if(indexes[0]>= max_index[0])
    status=1;
  return status;
}

