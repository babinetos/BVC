#include <stdio.h>
#include <stdlib.h>
FILE *open_f(char *filename, char mode);
