
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "vec_mat.h"
#include "files.h"
#include "rans.h"
/* #include <cblas.h> */
#include "inbred_functions.h"
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_multimin.h>
/* #include <cblas.h> */
#include <gsl_cblas.h> 

#include <gsl/gsl_roots.h>

double gsl_Q_beta_f(const gsl_vector *v, void *params);
void gsl_grad_Q_beta_f(const gsl_vector *v, void *params,gsl_vector *df);
void gsl_both_Q_beta_f(const gsl_vector *v, void *params,double *f,gsl_vector *df);
double gsl_Q_sigma_f(const gsl_vector *v, void *params);
void gsl_grad_Q_sigma_f(const gsl_vector *v, void *params,gsl_vector *df);
void gsl_both_Q_sigma_f(const gsl_vector *v, void *params,double *f,gsl_vector *df);

double gsl_one_Q_beta_f(double v, void *params);
double gsl_one_grad_Q_beta_f(double v, void *params);
void gsl_one_both_Q_beta_f(double v, void *params,double *f,double *df);

double one_hess_Q_beta_f(double beta,void *params);
void gsl_one_both_hess_Q_beta_f(double v, void *params,double *f,double *df);



int fdf_mininize_f( const gsl_vector *x,gsl_multimin_function_fdf my_func,gsl_multimin_fdfminimizer *s, double init_step, int max_iter, double tol);
int one_fdf_root_find_f( double x,gsl_function_fdf FDF,gsl_root_fdfsolver *s, int maxite, double tol);
