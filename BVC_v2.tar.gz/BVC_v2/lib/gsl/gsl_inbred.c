#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
/* #include "vec_mat.h" */
/* #include "files.h" */
/* #include "rans.h" */
#include "gsl_inbred.h"

/* #include <cblas.h> */
/* #include "inbred_functions.h" */
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_multimin.h>
/* #include <cblas.h> */
#include <gsl_cblas.h> 

#include <gsl/gsl_roots.h>


int fdf_mininize_f( const gsl_vector *x,gsl_multimin_function_fdf my_func,gsl_multimin_fdfminimizer *s, double init_step, int max_iter, double tol)
{
  int iter=0,status;
  
  gsl_multimin_fdfminimizer_set (s, &my_func, x, init_step,tol);
     
  do
    {
      iter++;
      status = gsl_multimin_fdfminimizer_iterate (s);
     
      if (status)
	break;
     
      status = gsl_multimin_test_gradient (s->gradient, tol);
      
    }
       while (status == GSL_CONTINUE && iter < max_iter);
 
  return status;
}

int one_fdf_root_find_f( double x,gsl_function_fdf FDF,gsl_root_fdfsolver *s, int maxite, double tol)
{
  int iter=0,status;
  
  gsl_root_fdfsolver_set (s, &FDF, x);
     
  do
    {
      iter++;
      status = gsl_root_fdfsolver_iterate (s);
     
      if (status)
	break;
     
        status = gsl_root_test_delta (gsl_root_fdfsolver_root (s), x,0, tol );
      
    }
       while (status == GSL_CONTINUE && iter < maxite);
 
  return status;
}

double gsl_one_Q_beta_f(double v, void *params)
{
  double b[1]={v};
  return Q_beta_f(b);
}

double gsl_one_grad_Q_beta_f(double v, void *params)
{
  double b[1]={v},df[1]={0};
  grad_Q_beta_f(b,df);
  return df[0];
}

void gsl_one_both_Q_beta_f(double v, void *params,double *f,double *df)
{
  double b[1]={v},df1[1]={0};
  grad_Q_beta_f(b,df1);
  *f = Q_beta_f(b);
  *df=df1[0];
}

double gsl_Q_beta_f(const gsl_vector *v, void *params)
{
  return Q_beta_f(v->data);
}
void gsl_grad_Q_beta_f(const gsl_vector *v, void *params,gsl_vector *df)
{
  grad_Q_beta_f(v->data,df->data);

}

void gsl_both_Q_beta_f(const gsl_vector *v, void *params,double *f,gsl_vector *df)
{
  gsl_grad_Q_beta_f(v,params,df);
  *f = gsl_Q_beta_f(v,params);

}


double gsl_Q_sigma_f(const gsl_vector *v, void *params)
{
  return Q_sigma_f(v->data);
}

void gsl_grad_Q_sigma_f(const gsl_vector *v, void *params,gsl_vector *df)
{
  grad_Q_sigma_f(v->data,df->data);
}
void gsl_both_Q_sigma_f(const gsl_vector *v, void *params,double *f,gsl_vector *df)
{
  grad_Q_sigma_f(v->data,df->data);
  *f = Q_sigma_f(v->data);
}




double one_hess_Q_beta_f(double beta, void *params)
{
  /* The hessian of the covariate part of the Q function maximized */
  /* under the MCEM                                                */ 
  int i,m;
  double t,h,c;
  double H=0;

  cov_logit_cond_like(&beta,XB);

  for(i=0;i<ped.npeople;i++)
    {
      c=0;
      for(m=0;m<MC;m++)
	{
	  t=exp(XB[i]+MC_U.mat[m][i]);
	  h= t/pow((1+t),2);
	  c-= weights[m]*h;
         }
      H+=c*ped.covariates.mat[i][0]*ped.covariates.mat[i][0];
      
    }
  H/=-W;
  return H;
}

void gsl_one_both_hess_Q_beta_f(double v, void *params,double *f,double *df)
{
  double b[1]={v},df1[1]={0};
  grad_Q_beta_f(b,df1);
  *f = df1[0];
  *df=one_hess_Q_beta_f(v,params);
}

