/* #include "vec_mat.h" */

#define MAXLEN 10000
#define PI 3.14159265
#define MAXMC 600000

#define FALSE 0
#define TRUE  1

#define EPS 1e-12
#define TOOSMALL ((double) 1.0e-9)
#define FREE_ARG char*



typedef struct PED {
  int npeople; /* Total number in the pedigree. */
  int *p_ids;
  int *f_ids;
  int *m_ids;
  int *sexes;
  int *d_statuses;
  DMATRIX genos;
  int ncovars;
  DMATRIX covariates;
} PED_t;

#define max_alleles 10

typedef struct CHROM_MAP {
  int markers; /* Total number markers*/
  double *locs;
  double *dists; /* distance b/ marker i and i-1 */
  double *recfrc;
  int *alleles;
  double **ps;
} CHROM_MAP_t;



/* typedef struct MAP { */
/*   int markers; /\* number of markers in the datafile *\/ */
/*   int *alleles; */
/*   DMATRIX  proportions; */
/* } MAP_t; */

/* ################################################################ */
/* ################################################################ */
/* ################################################################ */

char matfiles[6][MAXLEN]; /* Matrix file names */

PED_t ped;           /* pedigree information */
CHROM_MAP_t MAP;     /* marker information */
/* int cmap=0;           /\* map conversion function *\/ */
DMATRIX *V_MATS;     /* Covar matrices V_i such that Sigma = sum{s_i^2*V_i} */
DMATRIX Null_CHOL;   /* Cholesky Decomposition for MC covar matrix */
DMATRIX MC_U;        /* Matrix for the MC sample */
int MC,MC_step;      /* Number of MC replicates, Thining step (M-H method) */
double *weights,W;   /* Sample weights for Importance sampling */

int nsigmas;          /* Number of variance components */
double **blims,**slims;
int *bpoints,*spoints;
int MC_like;
int start_MC;
double *sigma_hat,*beta_hat;  /* Estimates of variance components */
DMATRIX MC_outer;        /* Matrix for outer product of the MC samples */
double TOL;           /* Criterion max{|s_i|,|b_j|} < TOL */
double deltas[3];     /* For convergence criterion  max{|s_i| */

int BURN,maxite;

DMATRIX VS,VSI;       /*Matrices needed in the Q_s*/

double grads[MAXMC][5];
DMATRIX *GI_mats;   
double DET,DET_null;
DMATRIX VSI_null;   
DMATRIX temp_MAT;  

double XB[5000];
double ln2pi;

double adj;

double nu,bpois; /* Monitoring variables for poisson sub-sampling */

