int norm_test_vectors(int n,double *x,double *y,double TOL);


int df_min_f(int n_var,double (*f)(double *vars,double *pars),int (*df)(double *vars,double *grad, double *pars),int maxite,double *x, double *grad, DMATRIX H,double *fval, int fval_index, double *pars);

int df_BFGS_minimization_iteration_f(int n_var,int (*df)(double *vars,double *grad,double *pars),double *x,double *grad,DMATRIX H,double scale, double *pars);

int update_hessian_f(int n_var,DMATRIX H1,double *grad1,double *grad2,double *x1,double *x2,DMATRIX H2);


int tol_fdf_min_f(int n_var,double (*f)(double *vars,double *pars),int (*df)(double *vars,double *grad, double *pars),int maxite,double *x, double *grad, DMATRIX H,double *fval, int fval_index, double TOL, double *pars);


int fdf_BFGS_minimization_iteration_f(int n_var,int (*f)(double *vars,double *pars),int (*df)(double *vars,double *grad,double *pars),double *x,double *grad,DMATRIX H,double *pars);


double min_a_line_f(int nvar,double alim,double (*funct)(double *vars, double *pars), double *x1,double *x2,double *new_x,double *pars);
