#include "vars.h"

int read_pois_grid_info(char *infofile);

int read_cov_mats(char matfiles[6][MAXLEN]);
int readped(char *pedfile);
int read_marker_info_f(char *loc_file);

int V_hat_f(double *sigmas,DMATRIX V);

int weights_samples_f(double *prod,double *p0,double *w);
int probs_samples_f(int M,double *fs,double *p0,int s);
int log_weights_samples_f(double *prod,double *p0,double *w);
int log_probs_samples_f(int M,double *fs,double *p0,int s);


double log_Q_null_f(double *betas);
int grad_Q_null_f(double *betas, double *grad);
double logit_pdf(double b,double u, int aff);
double logit_cond_like(double *betas,double *u);
double log_logit_cond_like(double *prod,double *u);
int cov_logit_cond_like(double *betas,double *prod);
int grad_logit_cond_like(double *prod,double *u, double *grad);

double Q_beta_f(double *betas);
int grad_Q_beta_f(double *betas, double *grad);
int HESS_Q_beta_f(DMATRIX H);
int beta_MC_error_var_mat_f(double *prod,DMATRIX H,DMATRIX S);
int new_beta_MC_error_var_mat_f(double *prod,DMATRIX H,DMATRIX S);

int MC_outer_f(DMATRIX OUT_MC);
double Q_sigma_f(double *sigmas);
int grad_Q_sigma_f(double *sigmas, double *grad);
int hessian_Q_sigma_f(double *sigmas,double *grad, DMATRIX H);
int sigma_MC_error_var_mat_f(double *sigmas,DMATRIX H,DMATRIX S);
int new_sigma_MC_error_var_mat_f(double *sigmas,DMATRIX H,DMATRIX S);
double max_single_Qs_f(double *sigmas,DMATRIX Hs);
int set_mat_single_Q_s_f(double *sigmas);


int independ_std_norm_f(int n,double *samples);
int rand_mvnorm_f(int n/* ,double *mu */, DMATRIX CHOL, double *samples);
double cond_mvnorm_f(int n , int k, double x0, double *u, DMATRIX INV);


int metropolis_sample_f(int N,int step,DMATRIX CHOL,double *cov_prod, DMATRIX sample, double *wghts, int s);
int new_metropolis_sample_f(int N,int step,DMATRIX CHOL,double *cov_prod, DMATRIX sample, double *wghts, int s);
double metropolis_component_update_f(int n,double *u0, double *prod, double *rej_w0,DMATRIX INV);
int metropolis_componentwise_sample_f(int N,int burnin, int step,double *cov_prod, DMATRIX sample, double *wghts, int s);

int poiss_metropolis_componentwise_sample_f(int N,int burnin,double nu,double b,double *cov_prod, DMATRIX sample, double *wghts, int s);


double chi_square_f(int n_var,double *x,double *x0,DMATRIX H);
int BH_stopping_rule_f( int n_var,double *old_psi, double *new_psi,double d1, double d2);
int max_test_vectors(int n,double *x,double *y,double TOL);
int max_test_vectors(int n,double *x,double *y,double TOL);
int max_rel_test_vectors(int n,double *x,double *y,double max_per, double max_sign);
double chi_square_f(int n_var,double *x,double *x0,DMATRIX H);



double new_det_inv_mat_f(int n, DMATRIX m,DMATRIX mi);
double new_det_chol_inv_mat_f(int n, DMATRIX m,DMATRIX mi );

double b_grid_loglike_f(double *sigmas, double **lims,int *points, int n_MC, double *bmaxs);
double loglike_f(double *betas, double *sigmas, int n_MC);
double grid_start_loglike_f(double **Slims, int *Spoints, double **Blims,int *Bpoints,int n_MC, double *bmaxs, double *smaxs);

double cM_to_rec_f(int func,double cM);
double rec_to_cM_f(int func,double theta);
