#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "vec_mat.h"
#include "files.h"
#include "cblas.h"
#include "rans.h"
#include "MCMCEM_functions.h"
#include "distributions.h"
/*################################################################*/

int cmap=0;           /* map conversion function */

double  max(double  one,double  two)
{
  if (one < two)
    return two;
   else
    return one ;

}


/*################################################################*/

int read_pois_grid_info(char *infofile)
{
  int i;
  char line[MAXLEN];
/*   char matfiles[6][MAXLEN]; */
  double lims[2];
  FILE *info;
  
  info=open_f(infofile,'r');
  fgets(line, MAXLEN, info);
  sscanf(line,"%d",&nsigmas);

   for(i=0;i<nsigmas;i++)
     {
       fgets(line, MAXLEN, info);
       sscanf(line,"%s",&matfiles[i]);
     }
    read_cov_mats(matfiles);
  
    sigma_hat=dvector(nsigmas);
    slims=dmatrix(nsigmas,2);
    spoints=ivector(nsigmas);
    for(i=0;i<nsigmas;i++)
     {
       fgets(line, MAXLEN, info);
       sscanf(line,"%lf%lf%d",&slims[i][0],&slims[i][1],&spoints[i]);
     }
    
    fgets(line, MAXLEN, info);
    sscanf(line,"%d",&i);
    
    if( i != ped.ncovars)
      {
	printf("<<ERROR>>\n");
	printf(" Number of covariates in info file  : %1d,\n Number of extra columns in ped file: %1d.\n",i,ped.ncovars);
	exit(1);
      }
   
    beta_hat=dvector(ped.ncovars);
    blims=dmatrix(ped.ncovars,2);
    bpoints=ivector(ped.ncovars);
    for(i=0;i<ped.ncovars;i++)
      {
       fgets(line, MAXLEN, info);
       sscanf(line,"%lf%lf%d",&blims[i][0],&blims[i][1],&bpoints[i]);
     }

   fgets(line, MAXLEN, info);
   sscanf(line,"%d",&BURN);
   fgets(line, MAXLEN, info);
   sscanf(line,"%d",&MC);
   if(MC>MAXMC)
     {
       printf("Number of MC iteration:%1d greater than maximum allowed (%1d).\n",MC,MAXMC);
       printf(" Instead, maximun is used\n");
       MC=MAXMC;
     }
   fgets(line, MAXLEN, info);
   sscanf(line,"%lf%lf",&nu,&bpois);
   fgets(line, MAXLEN, info);
   sscanf(line,"%lf",&TOL);
   fgets(line, MAXLEN, info);
   sscanf(line,"%lf%lf",&deltas[1],&deltas[2]);
   fgets(line, MAXLEN, info);
   sscanf(line,"%d",&maxite);
   start_MC=10000;
   if(fscanf(info,"%d",&i))
     start_MC=i;
   fgets(line, MAXLEN, info);
   MC_like=10000;
   if(fscanf(info,"%d",&i))
     MC_like=i;
  fclose(info);

  return 1;
}

/*################################################################*/
# define MAXPERSID 1000000

int read_cov_mats(char matfiles[6][MAXLEN])
{
 
  /**********************************************************/
  /* Reads the Covariance files for the variance components */
  /* It assumes that each file has three columns with the   */
  /* first two corresponding to the indiv ids, while the    */
  /* last is the relavant coefficients.                     */
  /* IMPORTANT: The order of the indivs in the matrix file  */
  /* is the same as the pedigree file.                      */
  /**********************************************************/
  
  int i,j,k,n,misscoeff=0,missflag=0;
  int p1,p2,persposition[MAXPERSID];
  double temp;
  FILE *var;
  
  n=ped.npeople;

  for(i=0;i<n;i++)
    {
      if(ped.p_ids[i] >= MAXPERSID)
	{
	  printf("Person's %1d ID (%1d) exceeds maximumm allowable (%1d).\n",i+1,ped.p_ids[i],MAXPERSID);
	  exit(1);
	}

      persposition[ped.p_ids[i]]=i;
    }


  V_MATS=(DMATRIX *)calloc(nsigmas,sizeof(DMATRIX));
  for(i=0;i<nsigmas;i++)
    V_MATS[i]=alloc_DMATRIX(n,n);

  
  Null_CHOL=alloc_DMATRIX(n,n);
  VSI_null=alloc_DMATRIX(ped.npeople,ped.npeople);
  VS=alloc_DMATRIX(ped.npeople,ped.npeople);
  VSI=alloc_DMATRIX(ped.npeople,ped.npeople);   
  
  GI_mats=(DMATRIX *)calloc(nsigmas,sizeof(DMATRIX));
  for(k=0;k<nsigmas;k++)
    {
      GI_mats[k]=alloc_DMATRIX(n,n);
      for(i=0;i<n;i++)
	for(j=i;j<n;j++)
	  V_MATS[k].mat[i][j]=V_MATS[k].mat[j][i]=-10;
    }
  
  for(k=0;k<nsigmas;k++)
    {
      misscoeff=0;
      var=open_f(matfiles[k],'r');
      
      for(i=0;i<n;i++)
        {
          for(j=i;j<n;j++)
            {
              fscanf(var,"%d%d%lf",&p1,&p2,&temp);
	      p1=persposition[p1];
	      p2=persposition[p2];
              V_MATS[k].mat[p1][p2]=V_MATS[k].mat[p2][p1]=temp;
            }
        }

     for(i=0;i<n;i++)
      for(j=i;j<n;j++)
	 if(V_MATS[k].mat[i][j]==-10.0)
	   {
	     misscoeff=1;
	     missflag=1;
	   }

     if( misscoeff==1)
       {
	  printf("<<<<<<<<<<<< Error >>>>>>>>>>>>\n");
	  printf("Some correlation coefficients are missing from file %s.\nThe following pairs of individuals have missing coeeficients:\n",matfiles[k]);
	  for(i=0;i<n;i++)
	    for(j=i;j<n;j++)
	      if(V_MATS[k].mat[i][j]==-10.0)
		printf("%7d\t%7d\n",ped.p_ids[i],ped.p_ids[j]);
       }

      fclose(var);
    }

  if(missflag==1)
    exit(1);	 
  return 1;
}


/*################################################################*/

int read_marker_info_f(char *loc_file)
{
  /*****************************************************************/
  /*   this function reads the marker information. It takes as an  */
  /*   argument the name of a file whose format is the one for the */
  /*   standard linkage programs. If all given distances are less  */
  /*   than .5, the function automatically assumes that they are   */
  /*   recombination fractions, and converts them into cM.         */
  /*****************************************************************/

  int i,j,check=0;
  char junk[5000];
  FILE *mark_info;
  
  mark_info = fopen(loc_file,"r");
  fscanf(mark_info,"%d%5000[^\n]",&MAP.markers,junk);
  MAP.markers--;
  MAP.alleles=ivector(MAP.markers+1);
  MAP.locs=dvector(MAP.markers+1);
  MAP.dists=dvector(MAP.markers+1);
  MAP.recfrc=dvector(MAP.markers+1);
  MAP.ps=dmatrix(MAP.markers+1,max_alleles);

  fgetc(mark_info);
  fscanf(mark_info,"%5000[^\n]",junk);
  fgetc(mark_info);

  for(i=0;i<=MAP.markers;++i)
    fscanf(mark_info,"%d",&j);
  fscanf(mark_info,"%5000[^\n]",junk);
  fgetc(mark_info);
  
  for(i=1;i<=4;++i)
    {
      fscanf(mark_info,"%5000[^\n]",junk);
      fgetc(mark_info);
    }
  for(i=1;i<=MAP.markers;++i)
    {
      fscanf(mark_info,"%d%d%200[^\n]",&j,&MAP.alleles[i],junk);
      MAP.ps[i][0]=0;
       for (j = 1; j<=MAP.alleles[i];j++)
	fscanf(mark_info,"%lf",&MAP.ps[i][j]);
    }

 
  fscanf(mark_info,"%*d");
  fscanf(mark_info,"%200[^\n]",junk);
  fgetc(mark_info);

  for(i=1;i<=MAP.markers;++i)
    {
      fscanf(mark_info,"%lf",&MAP.dists[i]);
      if(MAP.dists[i] <= 0)
	MAP.dists[i]=.000001;
  
      if(MAP.dists[i] < .5)
	check++;
    }

  if( check == MAP.markers)
    {
      for(i=1;i<=MAP.markers;++i)
	MAP.recfrc[i]=MAP.dists[i];

      for(i=1;i<=MAP.markers;++i)
	MAP.dists[i]=rec_to_cM_f(cmap,MAP.dists[i]);
    }else
      {
	for(i=1;i<=MAP.markers;++i)
	  MAP.recfrc[i]=cM_to_rec_f(cmap,MAP.dists[i]);
      }
  MAP.locs[1]=MAP.dists[1];
  for(i=2;i<=MAP.markers;++i)
    MAP.locs[i]=MAP.locs[i-1]+MAP.dists[i];
  fclose(mark_info);

  return 1;

}
/*################################################################*/

int readped(char *pedfile)
{
  /************************************************************/
  /* This function reads the pedigree information. It assumes */
  /* standard linkage format, where the covariates are the    */
  /* placed after the genotypes                               */
  /************************************************************/



   FILE *pedfl;
   int i,j,npeop,add_info=5;
   char line[MAXLEN];
   double a1,a2;
   pedfl=open_f(pedfile,'r');

   for(npeop=0; fgets(line, MAXLEN, pedfl);npeop++) {
   if(npeop == 1)
     {
       i=word_cnt(line);
       ped.ncovars= i - 2 * MAP.markers - add_info;
     }
   }
   rewind(pedfl);
   ped.npeople = npeop;
   ped.p_ids=ivector(npeop);
   ped.f_ids=ivector(npeop);
   ped.m_ids=ivector(npeop);
   ped.sexes=ivector(npeop);
   ped.d_statuses=ivector(npeop);


   if(MAP.markers>0)
     {
       ped.genos=alloc_DMATRIX(ped.npeople,MAP.markers);
     }
  if(ped.ncovars>0)
     ped.covariates=alloc_DMATRIX(npeop,ped.ncovars);

   for(i=0;i<ped.npeople;i++)
     {
       fscanf(pedfl,"%d%d%d%d%d",&ped.p_ids[i],&ped.f_ids[i],&ped.m_ids[i],&ped.sexes[i],&ped.d_statuses[i]);

   ped.d_statuses[i]--;
   for(j=0;j<MAP.markers;j++)
     {
       fscanf(pedfl,"%lf%lf",&a1,&a2);
       ped.genos.mat[i][j]=a1+a2-2;
     }
   for(j=0;j<ped.ncovars;j++)
     fscanf(pedfl,"%lf",&ped.covariates.mat[i][j]);
     }
   return 0;
}

/*################################################################*/

int V_hat_f(double *sigmas,DMATRIX V)
{
  /* Computes the over all Covariance matrix */
  int i,j,k,n=ped.npeople;
  for(i=0;i<n;i++)
    {
      V.mat[i][i]=0;
      for(j=0;j<i;j++)
	V.mat[i][j]=V.mat[j][i]=0;
    }

  for(k=0;k<nsigmas;k++)
    for(i=0;i<n;i++)
      cblas_daxpy(n,pow(sigmas[k],2),V_MATS[k].mat[i],1,V.mat[i],1);
    return 1;
}
/*################################################################*/


int log_weights_samples_f(double *prod,double *p0,double *w)
{
  /* computes the log of the importance weight of each MC sample */
  /* under the current model parameters                          */
  int m,n=ped.npeople;
  double temp[ped.npeople],t,c,f,g;

  c=-.5*(n*ln2pi + DET);
  W=0;
  for(m=0;m<MC;m++)
    {
      f=log_logit_cond_like(prod,MC_U.mat[m]);
      cblas_dsymv(CblasRowMajor,CblasUpper,ped.npeople,-.5,VSI.arr,ped.npeople,MC_U.mat[m],1,0,temp,1);
     t=cblas_ddot(n,MC_U.mat[m],1,temp,1);
     g=t+c;
     w[m]=exp(f+g-p0[m]);
      W+=w[m];
    }
  return 1;
}


/*################################################################*/

int log_probs_samples_f(int M,double *fs,double *p0,int s)
{
  /* computes the log-probability of each MC sample under the null model */
  int m,n=ped.npeople;
  double temp[ped.npeople],t,g,c;
  double g1,t1;
  c=-.5*(n*ln2pi + DET_null);
 for(m=s;m<M;m++)
    {
      cblas_dsymv(CblasRowMajor,CblasUpper,ped.npeople,-.5,VSI_null.arr,ped.npeople,MC_U.mat[m],1,0,temp,1);
      t=cblas_ddot(n,MC_U.mat[m],1,temp,1);
      g=t + c;
      p0[m]=g+fs[m];
    }
  return 1;
}



/*################################################################*/

double logit_pdf(double b,double u, int aff)
{
  /* The logit function, given the latent variables u */

  double L,p,t;
  t=exp(b+u);
  p= t/(1+t);
  L=pow(p,aff)*pow(1-p,1-aff);
  return L;
}

/*################################################################*/

double logit_cond_like(double *prod,double *u)
{
  /* The logistic likelihood function, given the latent variables u */

  int i;
  double L,s=0,p=1,t;
  for(i=0;i<ped.npeople;i++)
    {
      t=prod[i]+u[i];
      s+=ped.d_statuses[i]*t;
      p*=(1+exp(t));
    }
  L=exp(s)/p;
  return L;
}

/*################################################################*/

double log_logit_cond_like(double *prod,double *u)
{
  /* The logistic likelihood function, given the latent variables u */

  int i;
  double L,s=0,p=0,t;
  for(i=0;i<ped.npeople;i++)
    {
      t=prod[i]+u[i];
      s+=ped.d_statuses[i]*t;
      p+=log(1+exp(t));
     }
  L=s-p;
  return L;
}



/*################################################################*/

int cov_logit_cond_like(double *betas,double *prod)
{
  int i;
  /* The logistic likelihood function, given the latent variables u */

  if(ped.ncovars>0)
    {
      cblas_dgemv(CblasRowMajor,CblasNoTrans,ped.npeople,ped.ncovars,1.0,ped.covariates.arr,ped.covariates.cols,betas,1,0,prod,1);
    }else
      {
	for(i=0;i<ped.npeople;i++)
	  prod[i]=0;
      }
  return 1;
}


/*################################################################*/

int grad_logit_cond_like(double *prod,double *u, double *grad)
{
  /* The gradient of the logistic likelihood function,
     given the latent variables u */

  int i;
  double t,p,dp;
  for(i=0;i<ped.ncovars;i++)
    grad[i]=0;

  for(i=0;i<ped.npeople;i++)
    {
      t=exp(prod[i]+u[i]);
      cblas_daxpy(ped.ncovars,ped.d_statuses[i]-t/(1+t),ped.covariates.mat[i],1,grad,1);
    }
  return 1;
}



/*################################################################*/

double log_Q_null_f(double *betas)
{
  
  /* Log-Likelihhod function under the non-genetic model, */
  /* that is assuming no genetic effects                  */
  int i;
  double L,s=0,p=0,t;
  
  cov_logit_cond_like(betas,XB);
  
  for(i=0;i<ped.npeople;i++)
    {
      s+=ped.d_statuses[i]*XB[i];
      p+=log(1+exp(XB[i]));
    }
  L=s-p;
  return -L;
}

/*################################################################*/


int grad_Q_null_f(double *betas, double *grad)
{
  /* Gredient of log-Likelihhod function under the non-genetic */
  /* model, that is assuming no genetic effects                */
  int i,m,k;
  double t,p,dp;
  double temp;

  cov_logit_cond_like(betas,XB);
  for(i=0;i<ped.ncovars;i++)
    grad[i]=0;
  i=0; 
  for(i=0;i<ped.npeople;i++)
    {
      t=1/(1+exp(XB[i]));
      for(k=0;k<ped.ncovars;k++)
	grad[k]-= (t + ped.d_statuses[i]-1)*ped.covariates.mat[i][k];
    }

  return 1;
}


/*################################################################*/


double Q_beta_f(double *betas)
{
  /* The covariate part of the Q function maximized under the MCEM */ 
  
  int i,m;
  double t,L,p,Q_b=0;

  cov_logit_cond_like(betas,XB);

  for(m=0;m<MC;m++)
    {
      L=log_logit_cond_like(XB,MC_U.mat[m]);
	Q_b+=L*weights[m];
    }

  Q_b/=-W;
  return Q_b;
}



/*################################################################*/


int grad_Q_beta_f(double *betas, double *grad)
{
  /* The grad of the covariate part of the Q function maximized */
  /* under the MCEM                                             */ 
  int i,m,k;
  double t,p,dp;
  double temp;

  cov_logit_cond_like(betas,XB);

  for(i=0;i<ped.ncovars;i++)
    grad[i]=0;
  i=0; 
      for(i=0;i<ped.npeople;i++)
	{
	  temp=0;
	  for(m=0;m<MC;m++)
	    {
	      t=XB[i]+MC_U.mat[m][i];
	      temp+=weights[m]/(1+exp(t));
	    }
	  temp/=W;
	  
	  for(k=0;k<ped.ncovars;k++)
	    grad[k]-= (temp+ ped.d_statuses[i]-1)*ped.covariates.mat[i][k];
	}

  return 1;
}

/*################################################################*/

int HESS_Q_beta_f(DMATRIX H)
{
  /* The hessian of the covariate part of the Q function maximized */
  /* under the MCEM                                                */ 
  int i,m,j,k;
  double t,h,dh,dh2,c,y;
  double temp[ped.npeople];

  for(j=0;j<ped.ncovars;j++)
    {
      H.mat[j][j]=0;
      for(k=0;k<j;k++)
	H.mat[j][k]=H.mat[k][j]=0;
    }
   for(i=0;i<ped.npeople;i++)
     {
       c=0;
       for(m=0;m<MC;m++)
	 {
	   t=exp(XB[i]+MC_U.mat[m][i]);
	   h= t/pow((1+t),2);
	   c-= weights[m]*h;
	 }
       for(j=0;j<ped.ncovars;j++)
	 {
	   H.mat[j][j]+=c*ped.covariates.mat[i][j]*ped.covariates.mat[i][j];
	   for(k=0;k<j;k++)
	     H.mat[j][k]+=c*ped.covariates.mat[i][j]*ped.covariates.mat[i][k];
	 }
	  
     }
   for(j=0;j<ped.ncovars;j++)
     {
       H.mat[j][j]/=-W;
       for(k=0;k<j;k++)
	 H.mat[j][k]/=-W;
     }
   for(j=0;j<ped.ncovars;j++)
     for(k=0;k<j;k++)
       H.mat[k][j]=H.mat[j][k];
  return 1;
}


/*################################################################*/

int beta_MC_error_var_mat_f(double *prod,DMATRIX H,DMATRIX S)
{

  /* computes the MC covar matrix as in Booth-Hobert (1999).    */
  /* Needs the grad function of the likelihood, and the Hessian */

  int m,i,j;
  double g[ped.ncovars],temp[ped.ncovars*ped.ncovars];
  double b=0;
  for(m=0;m<ped.ncovars*ped.ncovars;m++)
    temp[m]=0;

  for(m=0;m<MC;m++)
    {
      grad_logit_cond_like(prod,MC_U.mat[m],g);
      if(m>0)
	b=1;
      cblas_dgemm(CblasRowMajor,CblasTrans,CblasNoTrans,ped.ncovars,ped.ncovars,1,weights[m],g,ped.ncovars,g,ped.ncovars,b,S.arr,ped.ncovars);
    }
 for(i=0;i<ped.ncovars*ped.ncovars;i++)
   S.arr[i]/=W;


  cblas_dsymm(CblasRowMajor,CblasLeft,CblasUpper,ped.ncovars,ped.ncovars,1.0,H.arr,ped.ncovars,S.arr,ped.ncovars,0.0,temp,ped.ncovars);

  cblas_dsymm(CblasRowMajor,CblasRight,CblasUpper,ped.ncovars,ped.ncovars,1.0,H.arr,ped.ncovars,temp,ped.ncovars,0.0,S.arr,ped.ncovars);
 inv_mat_f(ped.ncovars,S,S);

  return 1;
}




/*################################################################*/
int MC_outer_f(DMATRIX OUT_MC)
{
  /* This function computes the Matrix with the weight sum of the */
  /* outer product of the MCMC sample realizations                */ 
  int m;
  
  m=0;
  cblas_dgemm(CblasRowMajor,CblasTrans,CblasNoTrans,ped.npeople,ped.npeople,1,weights[m],MC_U.mat[m],ped.npeople,MC_U.mat[m],ped.npeople,0,OUT_MC.arr,ped.npeople);

  for( m=1;m<MC;m++)
    cblas_dgemm(CblasRowMajor,CblasTrans,CblasNoTrans,ped.npeople,ped.npeople,1,weights[m],MC_U.mat[m],ped.npeople,MC_U.mat[m],ped.npeople,1,OUT_MC.arr,ped.npeople);

  return 1;
}

/*################################################################*/


double max_single_Qs_f(double *sigmas,DMATRIX Hs)
{
  /* Analytical maximum of the Q_s function under the assumption */
  /* of only one variance component.                             */

  int i;
  double TR,f;


  inv_mat_f(ped.npeople,V_MATS[0],VS);
  
  TR=0;
  for(i=0;i<ped.npeople;i++)
    TR+=cblas_ddot(ped.npeople,VS.mat[i],1,MC_outer.mat[i],1);
  TR/=W;
  sigmas[0]=sqrt(TR/ped.npeople);
  Hs.mat[0][0]=2*pow(ped.npeople,2)/TR,2;
  Hs.mat[0][0]=1/Hs.mat[0][0];
  f=.5*TR/sigmas[0];
  return 0;
}

/*################################################################*/

int set_mat_single_Q_s_f(double *sigmas)
{
  /* Analytical Hessian of the Q_s function under the assumption */
  /* of only one variance component.                             */
  int j;
  double u[ped.npeople];
  double D;

  V_hat_f(sigmas,VS);

  DET=log_det_inv_mat_f(ped.npeople,VS,VSI);

  for(j=0;j<nsigmas;j++)  
      cblas_dsymm(CblasRowMajor,CblasLeft,CblasUpper,ped.npeople,ped.npeople,1.0,VSI.arr,ped.npeople,V_MATS[j].arr,ped.npeople,0.0,GI_mats[j].arr,ped.npeople);

}

/*################################################################*/


double Q_sigma_f(double *sigmas)
{
  /* The sigma part of the Q function maximized under the MCEM */ 
  int i;
  double Q_s=0,T;
  V_hat_f(sigmas,VS);

  DET=log_det_inv_mat_f(ped.npeople,VS,VSI);
  T=0;
  for(i=0;i<ped.npeople;i++)
    T+=cblas_ddot(ped.npeople,VSI.mat[i],1,MC_outer.mat[i],1);
  Q_s=-.5*(ped.npeople*log(2*PI) + DET + T/W);
  return -Q_s;
}
/*################################################################*/
int grad_Q_sigma_f(double *sigmas, double *grad)
{
  /* The gradient of the sigma part of the Q function maximized */
  /* by the MCEM.                                               */ 
  int i,j,k;
  double sum,T;
  double u[ped.npeople];
  double D;

  V_hat_f(sigmas,VS);

  DET=log_det_inv_mat_f(ped.npeople,VS,VSI);

  for(j=0;j<nsigmas;j++)
    {
      
      cblas_dsymm(CblasRowMajor,CblasLeft,CblasUpper,ped.npeople,ped.npeople,1.0,VSI.arr,ped.npeople,V_MATS[j].arr,ped.npeople,0.0,GI_mats[j].arr,ped.npeople);

      T=0;
      for(i=0;i<ped.npeople;i++)
	T+=GI_mats[j].mat[i][i];

      cblas_dsymm(CblasRowMajor,CblasRight,CblasUpper,ped.npeople,ped.npeople,1.0,VSI.arr,ped.npeople,GI_mats[j].arr,ped.npeople,0.0,VS.arr,ped.npeople);

      sum=0;
      for(i=0;i<ped.npeople;i++)
	sum+=cblas_ddot(ped.npeople,VS.mat[i],1,MC_outer.mat[i],1);
      grad[j]=sigmas[j]*(T - sum/W);
    }
  return 1;
}

/*################################################################*/

int hessian_Q_sigma_f(double *sigmas,double *grad, DMATRIX H)
{
  /* The hessian of the genetic (sigma) part of the Q function */
  /* maxized by the MCEM                                       */ 
  int i,j,k;
  int n;
  double sum,T;
  n=ped.npeople;

  for(j=0;j<nsigmas;j++)
    {
      if(fabs(sigmas[j])<.0001)
	sigmas[j]=.0001;
      
      for(k=0;k<=j;k++)
	{
	  if(fabs(sigmas[k])<.0001)
	    sigmas[k]=.0001;

	  cblas_dgemm(CblasRowMajor,CblasNoTrans,CblasNoTrans,ped.npeople,ped.npeople,ped.npeople,1.0,GI_mats[j].arr,ped.npeople,GI_mats[k].arr,ped.npeople,0.0,temp_MAT.arr,ped.npeople);
      
	  T=0;
	  for(i=0;i<ped.npeople;i++)
	    T+=temp_MAT.mat[i][i];

	  cblas_dsymm(CblasRowMajor,CblasRight,CblasUpper,ped.npeople,ped.npeople,1.0,VSI.arr,ped.npeople,temp_MAT.arr,ped.npeople,0.0,VS.arr,ped.npeople);

	  sum=0;
	  for(i=0;i<ped.npeople;i++)
	      sum+=cblas_ddot(ped.npeople,VS.mat[i],1,MC_outer.mat[i],1);
	  H.mat[j][k]=H.mat[k][j]=-2*sigmas[j]*sigmas[k]*(T - 2*sum/W) ;
	} 
     if(fabs(sigmas[j])>.01)
	H.mat[j][j]-=2*grad[j]/sigmas[j];
    }

  return 0;
}




/*################################################################*/

int sigma_MC_error_var_mat_f(double *sigmas,DMATRIX H,DMATRIX S)
{
  /* Computes the MC covar matrix as in Booth-Hobert (1999).    */
  /* Needs the grad function of the likelihood, and the Hessian */

  int i,j,k;
  double b=0,T,D,c=1.0/W;
  double u[ped.npeople];

  for(j=0;j<nsigmas;j++)
    {
      if(fabs(sigmas[j])<.0001)
	sigmas[j]=.0001;
      T=0;
      for(i=0;i<ped.npeople;i++)
	T+=GI_mats[j].mat[i][i];

      cblas_dsymm(CblasRowMajor,CblasRight,CblasUpper,ped.npeople,ped.npeople,1.0,VSI.arr,ped.npeople,GI_mats[j].arr,ped.npeople,0.0,temp_MAT.arr,ped.npeople);
      for(i=0;i<MC;i++)
	{
	  cblas_dsymv(CblasRowMajor,CblasUpper,ped.npeople,1,temp_MAT.arr,ped.npeople,MC_U.mat[i],1,0,u,1);
	  grads[i][j]=-sigmas[j]*(-T + cblas_ddot(ped.npeople,MC_U.mat[i],1,u,1));
	}
    }
  for(i=0;i<MC;i++)
    {
      if(i>0)
	b=1;
      cblas_dgemm(CblasRowMajor,CblasTrans,CblasNoTrans,nsigmas,nsigmas,1,weights[i],grads[i],nsigmas,grads[i],nsigmas,b,S.arr,nsigmas);
      
    }
  
  for(i=0;i<nsigmas*nsigmas;i++)
    S.arr[i]/=W;
 
  cblas_dsymm(CblasRowMajor,CblasLeft,CblasUpper,nsigmas,nsigmas,1,H.arr,nsigmas,S.arr,nsigmas,0.0,temp_MAT.arr,nsigmas);
  cblas_dsymm(CblasRowMajor,CblasRight,CblasUpper,nsigmas,nsigmas,1.0,H.arr,nsigmas,temp_MAT.arr,nsigmas,0.0,S.arr,nsigmas);
  
  inv_mat_f(nsigmas,S,S);
  
  return 1;
}


/*################################################################*/
/*################################################################*/

int independ_std_norm_f(int n,double *samples)
{
  /* Generates n independent realizations from a std. normal */

  int i,j,s,n_2;
  double u1,u2;

  n_2=floor(n/2);
  for(i=0;i<n_2;i++)
    {
      u1=rans();
      u2=rans();
      samples[2*i] = sqrt( -2 * log(u1) )* cos( 2 *PI* u2 );
      samples[2*i+1] = sqrt( -2 * log(u1) )* sin( 2 *PI* u2 );
    }
  if(n%2 == 1)
    {
      u1=rans();
      u2=rans();
      samples[2*i] = sqrt( -2 * log(u1) )* cos( 2 *PI* u2 );
    }

  return 1;
}


/*################################################################*/

int rand_mvnorm_f(int n/* ,double *mu */, DMATRIX CHOL, double *samples)
{
  /* Generates a realization from a MVN with mean zero and S=CHOL'*CHOL */
  /* Where CHOL is the lower triangular Cholesky decomposition matrix  */
  int i,j,s,n_2;
  double u1,u2;
  n_2=(int)floor((double)n/2);
  for(i=0;i<n_2;i++)
    {
      u1=rans();
      u2=rans();
      samples[2*i] = sqrt( -2 * log(u1) )* cos( 2 *PI* u2 );
      samples[2*i+1] = sqrt( -2 * log(u1) )* sin( 2 *PI* u2 );
    }
  if(n%2 == 1)
    {
      u1=rans();
      u2=rans();
      samples[2*i] = sqrt( -2 * log(u1) )* cos( 2 *PI* u2 );
    }
  cblas_dtrmv(CblasRowMajor,CblasLower, CblasNoTrans,CblasNonUnit,n,CHOL.arr,n,samples,1);

  return 1;
}

/*################################################################*/

double cond_mvnorm_f(int n , int k, double x0, double *u, DMATRIX INV)
{
  /* Generates a realization from the conditional distribution of */
  /* the kth component given all the other copmponents assumming  */
  /* a MVN joint distrbution with mean 0 and S=(INV)^-1           */
  /* vector u has the currnt values of all n components           */
  /* x0 is a realization from a univariate std normal             */
  double x,y;
  x=u[k];
  u[k]=0;
  y=x0/sqrt(INV.mat[k][k])-cblas_ddot(n,u,1,INV.mat[k],1)/INV.mat[k][k];
  u[k]=x;
  
  return y;
}

/*################################################################*/

/*################################################################*/

int metropolis_componentwise_sample_f(int N,int burnin, int step,double *cov_prod, DMATRIX sample, double *wghts, int s)
{
  /* MCMC sampler that generates N realization from the null distribution */
 
  int i,m,n=ped.npeople;
  double new_u[ped.npeople];
  double rej_weights[ped.npeople];
  if(s==0)
    {
      rand_mvnorm_f(n,Null_CHOL,new_u);

      for(m=0;m<burnin;m++)
	metropolis_component_update_f(n,new_u,cov_prod,rej_weights,VSI_null);
    }else
      {
	cblas_dcopy(n,sample.mat[s-1],1,new_u,1);
      }

  for(i=0;i<n;i++)
      rej_weights[i]=logit_pdf(cov_prod[i],new_u[i],ped.d_statuses[i]);

  for(m=0;m<N;m++)
    { 
      for(i=1;i<=step;i++)
	wghts[s+m]=metropolis_component_update_f(n,new_u,cov_prod,rej_weights,VSI_null);
      cblas_dcopy(n,new_u,1,sample.mat[s+m],1);
    }

  return 1;
}

/*################################################################*/
int rand_poisson_f(double lambda)
{
  int i=0;
  double CP,u,p;
  u=rans();
  CP=exp(-lambda);
  p=CP;
  while( CP < u)
    {
      i++;
      p*=(lambda/i);
      CP+=p;
    }
  return i;
}


int poiss_metropolis_componentwise_sample_f(int N,int burnin,double nu,double b,double *cov_prod, DMATRIX sample, double *wghts, int s)
{
  int i,m,n=ped.npeople,step;
  double new_u[ped.npeople];
  double rej_weights[ped.npeople];
  if(s==0)
    {
      rand_mvnorm_f(n,Null_CHOL,new_u);

      for(m=0;m<burnin;m++)
	metropolis_component_update_f(n,new_u,cov_prod,rej_weights,VSI_null);
    }else
      {
	cblas_dcopy(n,sample.mat[s-1],1,new_u,1);
      }

  for(i=0;i<n;i++)
      rej_weights[i]=logit_pdf(cov_prod[i],new_u[i],ped.d_statuses[i]);

  for(m=0;m<N;m++)
    { 
      step= rand_poisson_f(nu*pow(m,b))+1;
      for(i=1;i<=step;i++)
	wghts[s+m]=metropolis_component_update_f(n,new_u,cov_prod,rej_weights,VSI_null);
      cblas_dcopy(n,new_u,1,sample.mat[s+m],1);
    }

  return 1;
}



/*################################################################*/

double metropolis_component_update_f(int n,double *u0, double *prod, double *rej_w0,DMATRIX INV)
{
  /* Component update for the MCMC sampler */
  /* It updates sequentially all the components in u0 and recomputes */
  /* the new log-probabilities of each component under the current   */
  /* parameters and stores them in rej_w0*/
  int i;
  double x,w,std_norm[n];
  double p=0;

  independ_std_norm_f(n,std_norm);

   for(i=0;i<n;i++)
     {
       x=cond_mvnorm_f(n,i,std_norm[i],u0,INV);
       w=logit_pdf(prod[i],x,ped.d_statuses[i]);
       if( w/rej_w0[i] > rans())
	 {
	   u0[i]=x;
	   rej_w0[i]=w;
	 }
       p+=log(rej_w0[i]);
     }
   return p;

}


/*################################################################*/

int BH_stopping_rule_f( int n_var,double *old_psi, double *new_psi,double d1, double d2)
{
  /* checks convergence max{|b_i^{k}-b_i^{k+1}|/(|b_i^{k}|+d1)} < d2 */
  /* see Booth & Hobert (1999) */
  int i,flag=1;
  double t;

  for(i=0;i<n_var;i++)
    {
      if(fabs(new_psi[i]-old_psi[i]) > .0001)
	{
	  t=fabs(new_psi[i]-old_psi[i])/(fabs(old_psi[i])+d1);
	  if(t>d2)
	    flag=0;
	}
    }
  return flag;
}

/*################################################################*/
int max_test_vectors(int n,double *x,double *y,double TOL)
{
  /* checks convergence max{|s_i^{k+1}|} < TOL */
 
  int i,j=1;
  double D=0;
  
  for(i=0;i<n;i++)
    if( fabs(x[i]-y[i]) > TOL)
      j=0;
      return j;
}


/*################################################################*/

int max_rel_test_vectors(int n,double *x,double *y,double max_per, double max_sign)
{
  /* checks convergence max{|s_i^{k+1}|} < TOL */
 
  int i,j=1;
  
  for(i=0;i<n;i++)
    if( (fabs((x[i]-y[i])/y[i])>.5) || (max(fabs(x[i]),fabs(x[i])) > max_sign && fabs((x[i]-y[i])/y[i])> max_per))
      j=0;
           
      return j;
}
/*################################################################*/

double chi_square_f(int n_var,double *x,double *x0,DMATRIX H)
{
  /* computes the distance of two vectors, given the inverse of the covar matrices */

  double c[n_var],chi;
  int i,j;

  cblas_daxpy(n_var,-1.0,x,1,x0,1);
  cblas_dsymv(CblasRowMajor,CblasLower,n_var,1.0,H.arr,n_var,x0,1,0,c,1);
  chi=MC*cblas_ddot(n_var,c,1,x0,1);

  return chi;
}


/*################################################################*/


int update_indexes_f(int n,int *indexes, int *max_index, int s)
{
  int i,status=0;

  indexes[n-1]++;
  for( i=n-2;i>=0;i--)
    if(indexes[i+1] >= max_index[i+1])
      {
	indexes[i+1]=s;
	indexes[i]++;
      }
  if(indexes[0]>= max_index[0])
    status=1;
  return status;
}


/*################################################################*/


double b_loglike_f(double *betas, int n_MC)
{
  /* Computes the MC estimate of the log-likehood of the 
     hierarchical model for the given value of the betas 
     based on an existing sample stored in the MC_U matrix */ 

  int i;
  double L=0;

  cov_logit_cond_like(betas,XB);
  for(i=0;i<n_MC;i++)
    {
      L+=logit_cond_like(XB,MC_U.mat[i]);
    }

  return L;
}


/*################################################################*/



double b_grid_loglike_f(double *sigmas, double **lims,int *points, int n_MC, double *bmaxs)
{
  
  /* Computes the MC estimate of the log-likehood of the 
     hierarchical model for a range of betas determined by 
     the lims, and the points variables, for a fixed value 
     of the sigmas */


  int i,j,c,r,k,status=0,max_i=0;
  double steps[ped.ncovars];
  double betas[ped.ncovars];
  int indexes[ped.ncovars];
  double *L,max_L=0;
  FILE *out;
  V_hat_f(sigmas,VS);
  cholesky_f(VS.mat,Null_CHOL.mat,ped.npeople,&i);
 
  if( ped.ncovars >0)
    {
      j=1;
      for(i=0;i<ped.ncovars;i++)
	{
	  j*=points[i];
	  indexes[i]=0;
	  steps[i]=0;
	  if(points[i] > 1)
	    steps[i]=(lims[i][1]-lims[i][0])/(points[i]-1);
	}
      L=dvector(j);
      for(i=0;i<j;i++)
	L[i]=0;
      c=n_MC/MAXMC;
      r=n_MC%MAXMC;
      for(j=1;j<=c;j++)
	{
	  for(i=0;i<MAXMC;i++)
	    rand_mvnorm_f(ped.npeople,Null_CHOL,MC_U.mat[i]);
	  status=0;
	  for(i=0;i<ped.ncovars;i++)
	    indexes[i]=0;
	  k=0;
	  while(status ==0)
	    {
	      for(i=0;i<ped.ncovars;i++)
		betas[i]=lims[i][0]+indexes[i]*steps[i];
	      L[k]+=b_loglike_f(betas,MAXMC);
	      status=update_indexes_f(ped.ncovars,indexes,points,0);	  
	      k++;
	    }
	}
      
      for(i=0;i<r;i++)
 	rand_mvnorm_f(ped.npeople,Null_CHOL,MC_U.mat[i]);
     
      status=0;
      for(i=0;i<ped.ncovars;i++)
	indexes[i]=0;
      
      k=0;
      while(status ==0)
	{
	  for(i=0;i<ped.ncovars;i++)
	    betas[i]=lims[i][0]+indexes[i]*steps[i];
	  L[k]+=b_loglike_f(betas,r);
	  if(L[k] > max_L && L[k] > L[k-1] && L[k] > L[k+1])
	    {
	      max_L=L[k];
	      cblas_dcopy(ped.ncovars,betas,1,bmaxs,1);
	    }
	  status=update_indexes_f(ped.ncovars,indexes,points,0);
	  k++;
	}
      
      status=0;
      for(i=0;i<ped.ncovars;i++)
	indexes[i]=0;
      
      k=0;
      while(status ==0)
	{
	  for(i=0;i<ped.ncovars;i++)
	    betas[i]=lims[i][0]+indexes[i]*steps[i];
	  L[k]=-log(L[k]/n_MC);
	  status=update_indexes_f(ped.ncovars,indexes,points,0);
	  k++;
	}
    }else
      {
	L=dvector(1);
	L[0]=0;
	c=n_MC/MAXMC;
	r=n_MC%MAXMC;
	for(i=0;i<n_MC;i++)
	  {
	    rand_mvnorm_f(ped.npeople,Null_CHOL,MC_U.mat[0]);
	    L[0]+=logit_cond_like(XB,MC_U.mat[0]);
	  }
	max_L=L[0];
	L[0]=-log(L[0]/n_MC)+log(adj);
      }
  free_dvector(L);

  return -log(max_L/n_MC)+log(adj);
}

/*################################################################*/


double loglike_f(double *betas, double *sigmas, int n_MC)
{
  /* Computes the MC estimate of the log-likehood of the 
     hierarchical model for the given value of the betas 
     and the sigmas */ 
  int i,n;
  double L=0;
  double u[ped.npeople];
  n=ped.npeople;

  cov_logit_cond_like(betas,XB);
  V_hat_f(sigmas,VS);
  cholesky_f(VS.mat,Null_CHOL.mat,ped.npeople,&i);
  for(i=0;i<n_MC;i++)
    {
      rand_mvnorm_f(ped.npeople,Null_CHOL,u);
      L+=logit_cond_like(XB,u);
    }
  L/=n_MC;
  
  return -log(L);
}


/*################################################################*/


double grid_start_loglike_f(double **Slims, int *Spoints, double **Blims,int *Bpoints,int n_MC, double *bmaxs, double *smaxs)
{
  /* Computes the MC estimate of the log-likehood of the 
     hierarchical model over a grid of parameter values */

  int i,j,c,r,k,status=0;
  double steps[nsigmas],maxL=10000,L;
  double sigmas[nsigmas];
  int indexes[nsigmas];
  double b[ped.ncovars];

  adj=pow(1,ped.npeople);

  for(i=0;i<nsigmas;i++)
    {
      indexes[i]=0;
      steps[i]=0;
      if(Spoints[i] > 1)
	steps[i]=(Slims[i][1]-Slims[i][0])/(Spoints[i]-1);
    }
  k=0;
  while(status ==0)
    {
      for(i=0;i<nsigmas;i++)
	sigmas[i]=Slims[i][0]+indexes[i]*steps[i];
      L=b_grid_loglike_f(sigmas,Blims,Bpoints,n_MC,b);

      if(L < maxL)
	{
	  maxL=L;
	  cblas_dcopy(ped.ncovars,b,1,bmaxs,1);
	  cblas_dcopy(nsigmas,sigmas,1,smaxs,1);
	}
      k++;
      status=update_indexes_f(nsigmas,indexes,Spoints,0);
    }
  return maxL;
}
 

/* ################################################# */ 


double rec_to_cM_f(int func,double theta)
{
/*    Converts rec fractions to cM using the  */
/*    designated function (0=hald, 1=Kos)     */
  double d;
  
  if( func ==1)
    {
      d=.25*log((1+2*theta)/(1-2*theta))*100;
    }else
      {
        d=-.5*log(1-2*theta)*100;
      }

  return d;
}

/*################################################################*/

double cM_to_rec_f(int func,double cM)
{
/*    Converts cM to rec fractions  using the  */
/*    designated function (0=hald, 1=Kos)      */
  double d;
  
  if( func ==1)
    {
      d=.5*tanh(2*cM/100);
    }else
      {
        d=.5*(1-exp(-2*cM/100));
      }
  return d;
}

