#include "rans.h"


double  max(double  one,double  two);
double  min(double  one,double  two);
/* ###################### */
/* Discrete Distributions */
/* ###################### */
int rand_poisson_f(double lambda);


/* ######################### */
/* Continuous  Distributions */
/* ######################### */

/* standard normal density function */
double ndf(double t);

/* standard normal cumulative distribution function */
double nc(double x);

/* returns the inverse of cumulative normal distribution function
Reference> The Full Monte, by Boris Moro, Union Bank of Switzerland
                        RISK 1995(2)*/
double cndev(double u);

